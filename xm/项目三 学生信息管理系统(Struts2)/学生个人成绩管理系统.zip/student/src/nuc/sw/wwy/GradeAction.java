package nuc.sw.wwy;

import java.util.ArrayList;

import java.util.List;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class GradeAction extends ActionSupport implements ModelDriven<Grade>{
	private Grade g=new Grade();
	  gradeDao gDao=new gradeDao();
	  private List<Grade> gradeList=new ArrayList<Grade>();

	public List<Grade> getGradeList() {
		return gradeList;
	}
	public void setGradeList(List<Grade> gradeList) {
		this.gradeList = gradeList;
	}

	public String findSnoGrade() throws Exception{
		   gradeList=gDao.findBySno(g.getSno());
		


			ActionContext.getContext().getSession().put("gradeList", gradeList);
		   return "findSnoOK";
	}
	@Override
	public Grade getModel() {
		// TODO Auto-generated method stub
		return g;
	}
}
