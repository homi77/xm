package nuc.sw.wwy;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import nuc.sw.yl.dbc.DBUtil;
import nuc.sw.zzy.dbc.DBConn;


public class gradeDao {
	 Connection conn=null;
	    PreparedStatement ps=null;
	    ResultSet rs=null;
	    public gradeDao(){
	    	conn=DBConn.getConnection();
	    }
	    public List<Grade> findBySno(int Sno) {
			// TODO Auto-generated method stub
			List<Grade> gradeList=new ArrayList<Grade>();
		    String sql="select * from grade where Sno=?";
		    try {
				ps=conn.prepareStatement(sql);
				ps.setInt(1, Sno);
				rs=ps.executeQuery();
				Grade g=null;
				while(rs.next()){
					g=new Grade();
                    g.setCno(rs.getString("Cno"));
                    g.setSno(rs.getInt("Sno"));
                    g.setName(rs.getString("name"));
                    g.setCredit(rs.getInt("credit"));
                    g.setGrade(rs.getInt("grade"));
                   
					gradeList.add(g);
					System.out.println(g.getCno());
					System.out.println(g.getSno());
					System.out.println(g.getName());
					System.out.println(g.getCredit());
					System.out.println(g.getGrade());
					System.out.println(g.getAvg());
				}
		    } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
			return gradeList;
		}
	   /* public void findBySnoAvg(int Sno) throws Exception  {
			// TODO Auto-generated method stub
	    	 
	    
			String sql="update grade set avg=(select avg FROM (SELECT avg(grade) as avg from grade group by Sno=1) as temp )where sno=? ";
			try {
				ps=conn.prepareStatement(sql);
				ps.setInt(1,Sno);
			}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			if(ps.executeUpdate()>0){	
				System.out.println("数据修改成功");
			}
			else{
				System.out.println("数据修改失败");
			}
			}	*/
	    
}
