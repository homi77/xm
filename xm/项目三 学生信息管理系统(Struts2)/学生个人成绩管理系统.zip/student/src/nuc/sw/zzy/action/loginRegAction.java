package nuc.sw.zzy.action;



import nuc.sw.zzy.vo.Login;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class loginRegAction extends ActionSupport implements ModelDriven<Login> {
	private Login login=new Login();

public String login() throws Exception {
	// TODO Auto-generated method stub
	if(login.getName().equals("杨蕾")&&login.getPsw().equals("123")&&login.getSelect().equals("teacher")){
		ActionContext.getContext().getSession().put("teacher", login.getName());
		return "teacherlogin";
	}
	else if(login.getName().equals("张钟颖")&&login.getPsw().equals("456")&&login.getSelect().equals("admit")){
		ActionContext.getContext().getSession().put("admit", login.getName());
			return "admitlogin";
	}else {
		ActionContext.getContext().put("error", "你无权登陆！");
		return ERROR;
	}
}
@Override
 public void validate(){
	// TODO Auto-generated method stub
	if(login.getName()==null||login.getName().trim().equals("")){
		this.addFieldError("nameError", "用户名不能为空！");
}
	if(login.getPsw()==null||login.getPsw().trim().equals("")){
		this.addFieldError("pswError", "密码不能为空！");
}
}
@Override
public Login getModel() {
	// TODO Auto-generated method stub
	return login;
}

	}

	

