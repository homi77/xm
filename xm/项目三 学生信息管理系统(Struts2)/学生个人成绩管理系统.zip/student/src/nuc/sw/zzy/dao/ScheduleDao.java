package nuc.sw.zzy.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import nuc.sw.zzy.dbc.DBConn;
import nuc.sw.zzy.vo.Schedule;

public class ScheduleDao implements BaseDao<Schedule>{
    Connection conn=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
    public ScheduleDao(){
    	conn=DBConn.getConnection();
    }
	@Override
	public List<Schedule> findAll() {
		// TODO Auto-generated method stub
		List<Schedule> scheduleList=new ArrayList<Schedule>();
		String sql="select * from schedule";
		try {
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			Schedule s=null;
			while(rs.next()){
				s=new Schedule();
				s.setCno(rs.getString("Cno"));
				s.setName(rs.getString("name"));
				s.setCredit(rs.getString("credit"));
				s.setTime((rs.getString("time")));
				s.setTeacher(rs.getString("teacher"));
				s.setSno(rs.getInt("Sno"));
				s.setPlace(rs.getString("place"));
				scheduleList.add(s);
				System.out.println("查询所有信息成功！");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return scheduleList;
	}
	@Override
	public List<Schedule> findByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Schedule> findByCno(String Cno) {
		// TODO Auto-generated method stub
		List<Schedule> scheduleList=new ArrayList<Schedule>();
	    String sql="select * from schedule where Cno=?";
	    try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, Cno);
			rs=ps.executeQuery();
			Schedule s=null;
			while(rs.next()){
				s=new Schedule();
				s.setCno(rs.getString("Cno"));
				s.setName(rs.getString("name"));
				s.setCredit(rs.getString("credit"));
				s.setTime((rs.getString("time")));
				s.setTeacher(rs.getString("teacher"));
				s.setSno(rs.getInt("Sno"));
				s.setPlace(rs.getString("place"));
				scheduleList.add(s);
		
			}
	    } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
		return scheduleList;
	}
	public List<Schedule> findBySno(int Sno) {
		// TODO Auto-generated method stub
		List<Schedule> scheduleList=new ArrayList<Schedule>();
	    String sql="select * from schedule where Sno=?";
	    try {
			ps=conn.prepareStatement(sql);
			ps.setInt(1, Sno);
			rs=ps.executeQuery();
			Schedule s=null;
			while(rs.next()){
				s=new Schedule();
				s.setCno(rs.getString("Cno"));
				s.setName(rs.getString("name"));
				s.setCredit(rs.getString("credit"));
				s.setTime((rs.getString("time")));
				s.setTeacher(rs.getString("teacher"));
				s.setSno(rs.getInt("Sno"));
				s.setPlace(rs.getString("place"));
				scheduleList.add(s);
			}
	    } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
		return scheduleList;
	}
	public void addSchedule(Schedule s){
		String sql="insert into schedule(Cno,name,credit,time,teacher,Sno,place) values(?,?,?,?,?,?,?)";
		try {
			ps=conn.prepareStatement(sql);
		    ps.setString(1, s.getCno());
		    ps.setString(2, s.getName());
		    ps.setString(3, s.getCredit());
		    ps.setString(4, s.getTime());
		    ps.setString(5, s.getTeacher());
		    ps.setInt(6, s.getSno());
		    ps.setString(7, s.getPlace());
		    System.out.println(s.getCno());
		    if(ps.executeUpdate()>0){
		    	System.out.println("添加信息成功！");
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void updateSchedule(Schedule s){
		String sql="update schedule set name=?,credit=?,time=?,teacher=?,Sno=?,place=? where Cno=?";
		try {
			ps=conn.prepareStatement(sql);
		    ps.setString(1, s.getName());
		    ps.setString(2, s.getCredit());
		    ps.setString(3, s.getTime());
		    ps.setString(4, s.getTeacher());	    
		    ps.setInt(5, s.getSno());
		    ps.setString(6, s.getPlace());
		    ps.setString(7, s.getCno());
		    if(ps.executeUpdate()>0){
		    	System.out.println("修改信息成功！");
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public boolean deleteSchedule(String Cno){
		boolean flag=false;
		String sql="delete from schedule where Cno=?";
		try {
			ps=conn.prepareStatement(sql);
		    ps.setString(1, Cno);
		    if(ps.executeUpdate()>0)
		    {
		    	flag=true;
		    	System.out.println("删除信息成功！");
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
}