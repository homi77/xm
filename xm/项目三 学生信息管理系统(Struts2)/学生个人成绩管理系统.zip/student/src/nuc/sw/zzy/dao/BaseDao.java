package nuc.sw.zzy.dao;

import java.util.List;

public interface BaseDao<T> {
   public List<T> findAll();
   public List<T> findByName(String name);
   public List<T> findByCno(String Cno);
}
