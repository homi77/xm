package nuc.sw.zzy.vo;

public class Login {
		private String name;
		private String psw;
		private String select;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getPsw() {
			return psw;
		}
		public void setPsw(String psw) {
			this.psw = psw;
		}
		public String getSelect() {
			return select;
		}
		public void setSelect(String select) {
			this.select = select;
		}
		

}
