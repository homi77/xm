package nuc.sw.zzy.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import nuc.sw.zzy.dbc.DBConn;
import nuc.sw.zzy.vo.Login;


public class UserDao {
	Connection conn=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
    public UserDao(){
    	conn=DBConn.getConnection();
    }
	public boolean isregistteacher(String name,String psw){
		boolean flag=false;
		String sql="select name,psw from teacher where name=? and psw=?";
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2, psw);
			rs=ps.executeQuery();
			if(rs.next()){
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	public boolean isregistadmit(String name,String psw){
		boolean flag=false;
		String sql="select name,psw from admit where name=? and psw=?";
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2, psw);
			rs=ps.executeQuery();
			if(rs.next()){
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
}
