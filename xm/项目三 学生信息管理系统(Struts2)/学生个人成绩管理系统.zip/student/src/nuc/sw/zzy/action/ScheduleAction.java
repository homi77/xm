package nuc.sw.zzy.action;

import java.util.ArrayList;

import java.util.List;
import nuc.sw.zzy.dao.ScheduleDao;
import nuc.sw.zzy.vo.Schedule;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class ScheduleAction extends ActionSupport implements ModelDriven<Schedule>{
	private Schedule s=new Schedule();
	ScheduleDao sDao=new ScheduleDao();
	private List<Schedule> scheduleList=new ArrayList<Schedule>();


public List<Schedule> getScheduleList() {
		return scheduleList;
	}
	public void setSchedule(List<Schedule> schedule) {
		this.scheduleList = scheduleList;
	}
public String findAllSchedule() throws Exception{
	   scheduleList=sDao.findAll();
	   ActionContext.getContext().getSession().put("scheduleList", scheduleList);
	   return "findScheduleOK";
   }
   public String findCnoSchedule(){
	  scheduleList=sDao.findByCno(s.getCno());
		ActionContext.getContext().getSession().put("scheduleList", scheduleList);
	   return "findCnoOK";
   }
   public String findSnoSchedule(){
	   scheduleList=sDao.findBySno(s.getSno());
		ActionContext.getContext().getSession().put("scheduleList", scheduleList);
	   return "findSnoOK";
   }
   public String updateSchedule(){
		sDao.updateSchedule(s);
		return "updateScheduleOK";
	}
   public String deleteSchedule(){
		sDao.deleteSchedule(s.getCno());
		return "deleteScheduleOK";
	}
   public String addSchedule() throws Exception{
		sDao.addSchedule(s);
		return "addScheduleOK";
	}
	@Override
	public Schedule getModel() {
		// TODO Auto-generated method stub
		return s;
	}

}
