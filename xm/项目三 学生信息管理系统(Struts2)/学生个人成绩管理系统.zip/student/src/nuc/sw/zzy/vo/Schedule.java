package nuc.sw.zzy.vo;

import java.sql.Date;
import java.sql.Time;

public class Schedule {
	private int id;
   private String Cno;
   private String name;
   private String credit;
   private String teacher;
   private String time;
   private int Sno;
   private String place;
 

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getCno() {
		return Cno;
	}
	public void setCno(String cno) {
		Cno = cno;
	}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCredit() {
	return credit;
}
public void setCredit(String credit) {
	this.credit = credit;
}


public String getTeacher() {
	return teacher;
}
public void setTeacher(String teacher) {
	this.teacher = teacher;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public int getSno() {
	return Sno;
}
public void setSno(int sno) {
	Sno = sno;
}
public String getPlace() {
	return place;
}
public void setPlace(String place) {
	this.place = place;
}
   
}
