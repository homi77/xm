package nuc.sw.zl.dao;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import nuc.sw.zl.dbc.*;
import nuc.sw.zl.vo.plan;
import nuc.sw.zl.dbc.DBConn;

public class planDao implements baseDao<plan> {

	Connection conn=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	public void insertPlan(plan plan) {
		// TODO Auto-generated method stub
		List<plan> plans=new ArrayList<plan>();
		conn=DBConn.getConnection();
		String sql="insert into plan(Sno,time,plan) values(?,?,?)";
		try {
			ps=conn.prepareStatement(sql);
				
		        ps.setInt(1, plan.getSno());
			    ps.setString(2, plan.getTime());
			    ps.setString(3, plan.getPlan());
			    if(ps.executeUpdate()>0){
					System.out.println("���ݲ���ɹ�");}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
     public List<plan> selectAllPlan(){
		// TODO Auto-generated method stub
		List<plan> plans=new ArrayList<plan>();
		conn=DBConn.getConnection();
		String sql="select * from plan";
		try {
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			plan plan=null;
			while(rs.next()){
				plan=new plan();
				plan.setSno(rs.getInt("Sno"));
				plan.setTime(rs.getString("time"));
				plan.setPlan(rs.getString("plan"));
				plans.add(plan);
		        System.out.println(plan.getTime());
		        System.out.println(plan.getSno());
		        System.out.println(plan.getPlan());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return plans;
	}
     public List<plan> selectSinPlan(int Sno) {
 		// TODO Auto-generated method stub
 		List<plan> plans=new ArrayList<plan>();
 		conn=DBConn.getConnection();
 		String sql="select * from plan where Sno=?";
 		try {
 			ps=conn.prepareStatement(sql);
 			ps.setInt(1,Sno);
 			  rs=ps.executeQuery();
 		 	plan plan=null;
 				if(rs.next()){
 					plan=new plan();
 					plan.setSno(rs.getInt("Sno"));
 					plan.setTime(rs.getString("time"));
 					plan.setPlan(rs.getString("plan"));
 					plans.add(plan);
 					System.out.println(plan.getSno());
 					System.out.println(plan.getTime());
 					System.out.println(plan.getPlan());	
 				}
 		} catch (SQLException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
 		return plans;
 	}
	public void updatePlan(plan plan) throws SQLException {
		// TODO Auto-generated method stub
		conn=DBConn.getConnection();
		String sql="update plan set time=?,plan=? where Sno=?";
		try{
			ps=conn.prepareStatement(sql);
		   
		    ps.setString(1, plan.getTime());
		    ps.setString(2, plan.getPlan());
		    ps.setInt(3,plan.getSno());
		   }catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(ps.executeUpdate()>0){
			System.out.print("�޸ĳɹ�");
		}else{
			System.out.print("�޸�ʧ��");	
		}
	}
     public void deletePlan(int Sno) {
		// TODO Auto-generated method stub
		conn=DBConn.getConnection();
		String sql="delete from plan where Sno=?";
		try{
			ps=conn.prepareStatement(sql);
			ps.setInt(1, Sno);
			
			if(ps.executeUpdate()>0){	
				System.out.println("����ɾ���ɹ�");
			}
			else{
				System.out.println("����ɾ��ʧ��");
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

 	
}

