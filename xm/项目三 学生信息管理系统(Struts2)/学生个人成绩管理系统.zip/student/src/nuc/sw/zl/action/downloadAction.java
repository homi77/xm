package nuc.sw.zl.action;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import com.opensymphony.xwork2.ActionSupport;

public class downloadAction extends ActionSupport {
	private String inputPath;
	private String contentType;
	private String downFileName;
	public String getInputPath() {
		return inputPath;
	}
	public void setInputPath(String inputPath) throws UnsupportedEncodingException {
		this.inputPath =  new String(inputPath.getBytes("iso-8859-1"),"UTF-8");
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	public String getDownFileName() throws UnsupportedEncodingException {
		return URLEncoder.encode(downFileName,"UTF-8");
	}
	public void setDownFileName(String downFileName) throws UnsupportedEncodingException {
		this.downFileName = new String(downFileName.getBytes("iso-8859-1"),"UTF-8");
	}
	public InputStream getFileDownload() throws Exception  {
		FileInputStream fis =new FileInputStream(inputPath);
		System.out.println(inputPath);
		return fis;
	}
}
