package nuc.sw.zl.vo;

import java.io.File;
import java.util.Date;

import com.opensymphony.xwork2.ActionSupport;

public class plan extends ActionSupport {
   
   private int Sno;
   private String time;
   private String plan;
   
public int getSno() {
	return Sno;
}
public void setSno(int sno) {
	Sno = sno;
}

public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getPlan() {
	return plan;
}
public void setPlan(String plan) {
	this.plan = plan;
}
 
}
