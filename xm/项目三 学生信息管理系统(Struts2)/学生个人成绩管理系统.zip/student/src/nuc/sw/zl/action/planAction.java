package nuc.sw.zl.action;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import nuc.sw.zl.dao.baseDao;
import nuc.sw.zl.dao.planDao;
import nuc.sw.zl.vo.plan;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class planAction extends ActionSupport implements ModelDriven<plan>{
  private List<plan> plans=new ArrayList<plan>();
  private List<plan> plan1=new ArrayList<plan>();
  
  public List<plan> getPlan1() {
	return plan1;
}
public void setPlan1(List<plan> plan1) {
	this.plan1 = plan1;
}
private plan plan=new plan();
  planDao pd=new planDao();
  public String insertPlan() {
		// TODO Auto-generated method stub
		
		pd.insertPlan(plan);
		return "insertOK";
	}
  public String selectAllPlan() {
		// TODO Auto-generated method stub
		plans=pd.selectAllPlan();
		ActionContext.getContext().getSession().put("plans", plans);
		System.out.println(plans.get(0));
		return "selectAllOK";
	}
  public List<plan> getPlans() {
		return plans;
	}
  public void setPlans(List<plan> plans) {
		this.plans = plans;
	}
	public String selectSinPlan(){
		System.out.println(plan.getSno());
		plan1=pd.selectSinPlan(plan.getSno());
		ActionContext.getContext().getSession().put("plan1",plan1);
		System.out.println(plan.getSno());
			System.out.println(plan.getTime());
			System.out.println(plan.getPlan());	
		return "selectSinOK";
		}
	
public String updatePlan() throws SQLException {
	// TODO Auto-generated method stub
	pd.updatePlan(plan);
	pd.selectSinPlan(plan.getSno());
	return "updateOK";
	
}
public String deletePlan() {
	// TODO Auto-generated method stub
    pd.deletePlan(plan.getSno());
	return "deleteOK";
}
@Override
public plan getModel() {
	// TODO Auto-generated method stub
	return plan;
}

}
