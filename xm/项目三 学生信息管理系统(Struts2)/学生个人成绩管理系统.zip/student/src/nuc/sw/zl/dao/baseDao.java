package nuc.sw.zl.dao;

import java.sql.SQLException;
import java.util.List;

public interface baseDao<plan> {
	public List<plan> selectAllPlan();
	public void updatePlan(plan plan) throws SQLException;
	public void insertPlan(plan plan);
	public void deletePlan(int Sno);
	public List<plan> selectSinPlan(int Sno);
}
