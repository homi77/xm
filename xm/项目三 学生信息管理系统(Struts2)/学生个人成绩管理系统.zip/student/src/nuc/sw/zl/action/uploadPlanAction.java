package nuc.sw.zl.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.UUID;

import com.opensymphony.xwork2.ActionSupport;

public class uploadPlanAction extends ActionSupport {
  private File upload;
  private String title;
  private String uploadFileName;
  private String uploadContentType;
  private String savePath;
public File getUpload() {
	return upload;
}
public void setUpload(File upload) {
	this.upload = upload;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getUploadFileName() {
	return uploadFileName;
}
public void setUploadFileName(String uploadFileName) {
	this.uploadFileName = uploadFileName;
}
public String getUploadContentType() {
	return uploadContentType;
}
public void setUploadContentType(String uploadContentType) {
	this.uploadContentType = uploadContentType;
}
public String getSavePath() {
	return savePath;
}
public void setSavePath(String savePath) {
	this.savePath = savePath;
}

	public String uploadMethod() throws Exception {
		// TODO Auto-generated method stub
		System.out.println(uploadFileName);
		System.out.println(uploadContentType);
		System.out.println(savePath);
		FileInputStream fis=new FileInputStream(upload);
		FileOutputStream fos=new FileOutputStream(savePath+"/"+UUID.randomUUID().toString()+uploadFileName);
		byte[] buf=new byte[1024];
		int len=0;
		while((len=fis.read(buf))>0){
			fos.write(buf,0,len);
		}
		return SUCCESS;
	}
}
