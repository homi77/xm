package nuc.sw.nyh.vo;

public class User {
     private int Sno;
     private String psw;
	
	public int getSno() {
		return Sno;
	}
	public void setSno(int Sno) {
		Sno = Sno;
	}
	public String getPsw() {
		return psw;
	}
	public void setPsw(String psw) {
		this.psw = psw;
	}
     
}
