package nuc.sw.nyh.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import nuc.sw.nyh.dbc.DBConn;
import nuc.sw.nyh.vo.Student;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class StudentDAO extends ActionSupport
{
	Connection conn=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	
    private List<Student> students=new ArrayList<Student>();
	    
	    public List<Student> getStudents() {
			return students;
		}

		public void setStudents(List<Student> students) {
			this.students = students;
		}
	
	public void addAllStudent(Student student) throws IOException {
		
		conn=DBConn.getConnection();
		String sql="insert into student(Sno,password,name,team,dept,age,sex,savePath,uploadFileName)values(?,?,?,?,?,?,?,?,?)";
		try {
			ps=conn.prepareStatement(sql);
			ps.setInt(1, student.getSno());
			ps.setString(2, student.getPassword());
			ps.setString(3, student.getName());
			ps.setString(4, student.getTeam());
			ps.setString(5, student.getDept());
			ps.setInt(6, student.getAge());
			ps.setString(7,student.getSex());
			ps.setString(8,student.getSavePath());
			ps.setString(9,student.getUploadFileName());
			if(ps.executeUpdate()>0){
				System.out.print("����ɹ�");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			FileInputStream fis=new FileInputStream(student.getUpload());
			FileOutputStream fos=new FileOutputStream(student.getSavePath()+"/"+student.getUploadFileName());
			byte[] buffer=new byte[1024];
			int len=0;
			while((len=fis.read(buffer))>0){
				fos.write(buffer, 0, len);
				
			}
		
	}

	public List<Student> searchAllStudent() {
		// TODO Auto-generated method stub
		List<Student> students=new ArrayList<Student>();
		conn=DBConn.getConnection();
		String sql="select * from student";
		try {
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			Student student=null;
			while(rs.next()){
				student=new Student();
				student.setSno(rs.getInt("Sno"));
				student.setPassword(rs.getString("password"));
				student.setName(rs.getString("name"));
				student.setTeam(rs.getString("team"));
				student.setDept(rs.getString("dept"));
				student.setAge(rs.getInt("age"));
				student.setSex(rs.getString("sex"));
				student.setSavePath(rs.getString("savePath"));
				student.setUploadFileName(rs.getString("UploadFileName"));
				students.add(student);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return students;
	
	}
	
	public List<Student> selectStudent(int Sno){
		List<Student> students=new ArrayList<Student>();
		conn=DBConn.getConnection();
		String sql="select * from student where Sno=?";
		try {
			ps=conn.prepareStatement(sql);
			ps.setInt(1, Sno);
			rs=ps.executeQuery();
			Student student=null;
			if(rs.next()){
				student=new Student();
				student.setSno(rs.getInt("Sno"));
				student.setPassword(rs.getString("password"));
				student.setName(rs.getString("name"));
				student.setTeam(rs.getString("team"));
				student.setDept(rs.getString("dept"));
				student.setAge(rs.getInt("age"));
				student.setSex(rs.getString("sex"));
				student.setSavePath(rs.getString("savePath"));
				student.setUploadFileName(rs.getString("UploadFileName"));
				students.add(student);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return students;	
	}
		public void deleteStudent(int Sno){
			conn=DBConn.getConnection();
			String sql="delete from Student where Sno=?";
			try {
				ps=conn.prepareStatement(sql);
				ps.setInt(1, Sno);
				if(ps.executeUpdate()>0){
					System.out.println("ɾ���ɹ�");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		public void updateStudent(Student student) throws IOException{
			conn=DBConn.getConnection();
			String sql="update student set password=?,name=?,team=?,dept=?,age=?,sex=?,savePath=?,uploadFileName=? where Sno=?";
			try {
				ps=conn.prepareStatement(sql);			
				ps.setString(1, student.getPassword());
				ps.setString(2, student.getName());
				ps.setString(3, student.getTeam());
				ps.setString(4, student.getDept());
				ps.setInt(5, student.getAge());
				ps.setString(6,student.getSex());
				ps.setString(7,student.getSavePath());
				ps.setString(8,student.getUploadFileName());
				ps.setInt(9, student.getSno());
				System.out.print(student.getSno());
				if(ps.executeUpdate()>0){
					System.out.print("�޸ĳɹ�");
				}else{
					System.out.print("�޸�ʧ��");	
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			FileInputStream fis=new FileInputStream(student.getUpload());
			FileOutputStream fos=new FileOutputStream(student.getSavePath()+"/"+student.getUploadFileName());
			byte[] buffer=new byte[1024];
			int len=0;
			while((len=fis.read(buffer))>0){
				fos.write(buffer, 0, len);
				
			}		
		}

		public boolean RegStudent(int Sno,String psw) {
			// TODO Auto-generated method stub
			boolean flag=false;
			conn=DBConn.getConnection();
			String sql="select * from student where Sno=? and password=?";
			try {
				ps=conn.prepareStatement(sql);
				ps.setInt(1, Sno);
				ps.setString(2,psw);
				rs=ps.executeQuery();
				if(rs.next()){
					System.out.println(Sno);
					flag=true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			return flag;
			
		}





}


