package nuc.sw.nyh.action;


import java.util.ArrayList;
import java.util.List;

import nuc.sw.nyh.dao.StudentDAO;
import nuc.sw.nyh.vo.Student;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class StudentAction extends ActionSupport implements ModelDriven<Student> {
    private List<Student> students=new ArrayList<Student>();
    
    public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	private Student student=new Student();
    StudentDAO Sdao=new StudentDAO();
	@Override
	public Student getModel() {
		// TODO Auto-generated method stub
		return student;
	}
	
	public String add_AllStudentActionMethod() throws Exception {
		// TODO Auto-generated method stub
		Sdao.addAllStudent(student);
		return "addStudentOK";
	}

	public String search_AllStudentActionMethod() throws Exception {
		// TODO Auto-generated method stub
	     students=Sdao.searchAllStudent();
	     ActionContext.getContext().getSession().put("students",students);
	    
		return "getStudentOK";
	}

	public String select_SignalStudentActionMethod() throws Exception {
		// TODO Auto-generated method stub
		System.out.println(student.getSno());
		students=Sdao.selectStudent(student.getSno());
		return "selectStudentOK";
	}
	public void validateAdd_AllStudentActionMethod(){
		if(student.getName()==null||student.getName().trim().equals("")){
			addFieldError("nameError","���ֲ���Ϊ��");
		}
	}

	public String delete_SignalStudentActionMethod() throws Exception {
		// TODO Auto-generated method stub
		System.out.println(student.getSno());
		Sdao.deleteStudent(student.getSno());
		return "deleteStudentOK";
	}
	
	public String Write_SignalStudentActionMethod() throws Exception {
		// TODO Auto-generated method stub
		Sdao.updateStudent(student);
		System.out.println(student.getSno());
		students=Sdao.selectStudent(student.getSno());
		return "WriteStudentOk";
	}
	

}
