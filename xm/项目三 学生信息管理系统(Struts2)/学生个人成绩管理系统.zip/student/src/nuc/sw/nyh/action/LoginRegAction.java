package nuc.sw.nyh.action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import nuc.sw.nyh.dao.StudentDAO;
import nuc.sw.nyh.vo.Student;
import nuc.sw.nyh.vo.User;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class LoginRegAction extends ActionSupport{

	 private int Sno;
     private String psw;
     private Student student;
     
     public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}
	private List<Student> students=new ArrayList<Student>();
     
     public List<Student> getStudents() {
 		return students;
 	}

 	public void setStudents(List<Student> students) {
 		this.students = students;
 	}
	public int getSno() {
		return Sno;
	}
	public void setSno(int Sno) {
		this.Sno = Sno;
	}
	public String getPsw() {
		return psw;
	}
	public void setPsw(String psw) {
		this.psw = psw;
	}
	StudentDAO Sdao=new StudentDAO();
	
	
	public String LoginRegActionMethod() throws Exception {
		// TODO Auto-generated method stub		  
		 boolean flag=Sdao.RegStudent(Sno,psw);	 
		if(flag==true){
			   
			  ActionContext.getContext().getSession().put("Sno",Sno);
			  return SUCCESS; 
		  }else {
			  ActionContext.getContext().put("error","用户名或密码错误！");
			  return ERROR;
		  }	
			  
		  
	}
	
	@Override
	public void validate() {
		// TODO Auto-generated method stub
		if(Sno==0){
			addFieldError("idError","请输入学号！");
		}
		if(psw==null||psw.trim().equals("")){
			addFieldError("pswError","请输入密码！");
		}
	}
	

}
