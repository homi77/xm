package nuc.sw.yl.dbc;
import java.sql.Connection;
import java.sql.DriverManager;
public class DBUtil {
	private static final String DBDRIVER="com.mysql.jdbc.Driver";
	private static final String DBURL="jdbc:mysql://localhost:3306/student";	
	private static final String DBUSER="root";
	private static final String DBPASSWORD="123456";
	private static Connection conn=null;
	static{
		try{
			   Class.forName(DBDRIVER);
			   conn=DriverManager.getConnection(DBURL,DBUSER,DBPASSWORD);
			}catch(Exception e){}
	}
	public DBUtil(){
		
	}
	public static Connection getConnection(){
		return conn;
	}
	public void close(){
		if(conn!=null){
		   try{
			conn.close();
		   }catch(Exception e){}
		}
	}
}
