package nuc.sw.yl.grade.Dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;









import nuc.sw.yl.dbc.DBUtil;
import nuc.sw.yl.vo.Grade;



public class gradeDao {
	Connection conn=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	public void addGrade(Grade grade) throws IOException{
		conn=DBUtil.getConnection();
		String sql="insert into grade (Cno,Sno,name,credit,grade) values(?,?,?,?,?)";

		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1,grade.getCno());
			ps.setInt(2,grade.getSno());
			ps.setString(3,grade.getName());
			ps.setInt(4,grade.getCredit());
			ps.setInt(5,grade.getGrade());
			if(ps.executeUpdate()>0){
				System.out.println("数据插入成功");}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<Grade> findAllGrade() {
		// TODO Auto-generated method stub
		List<Grade> grades=new ArrayList<Grade>();
	
		conn=DBUtil.getConnection();
		String sql="select * from grade";
		try {
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			Grade grade=null;
			while(rs.next()){
				grade=new Grade();
				grade.setCno(rs.getString("Cno"));
				grade.setSno(rs.getInt("Sno"));
				grade.setName(rs.getString("name"));
				grade.setCredit(rs.getInt("credit"));
				grade.setGrade(rs.getInt("grade"));
				grades.add(grade);
				System.out.println(grade.getCno());
				System.out.println(grade.getSno());
				System.out.println(grade.getName());
				System.out.println(grade.getCredit());
				System.out.println(grade.getGrade());	
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return grades;
	}
	public List<Grade> findAllGradeBySno(int Sno) throws IOException{
		List<Grade> grade1=new ArrayList<Grade>();
		conn=DBUtil.getConnection();
		String sql="select * from grade where Sno=?";
		try {
			ps=conn.prepareStatement(sql);
			ps.setInt(1,Sno);
			  rs=ps.executeQuery();
		 	Grade grade=null;
				while(rs.next()){
					grade=new Grade();
					grade.setCno(rs.getString("Cno"));
					grade.setSno(rs.getInt("Sno"));
					grade.setName(rs.getString("name"));
					grade.setCredit(rs.getInt("credit"));
					grade.setGrade(rs.getInt("grade"));
					grade1.add(grade);
					System.out.println(grade.getCno());
					System.out.println(grade.getSno());
					System.out.println(grade.getName());
					System.out.println(grade.getCredit());
					System.out.println(grade.getGrade());	
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return grade1;
	}
	public void deleteGrade(int Sno) throws IOException{
		conn=DBUtil.getConnection();
	String sql="delete from grade where Sno=?";
	try {
	ps=conn.prepareStatement(sql);
	   ps.setInt(1,Sno);
	if(ps.executeUpdate()>0){	
		System.out.println("数据删除成功");
	}
	else{
		System.out.println("数据修改失败");
	}
}catch(Exception e){
	e.printStackTrace();
}
}
	
	public List<Grade> findAllGradeBySnoAndCno(int Sno,String Cno) throws IOException{
		List<Grade> grade2=new ArrayList<Grade>();
		conn=DBUtil.getConnection();
		String sql="select * from grade where Sno=? and Cno=?";
		try {
			ps=conn.prepareStatement(sql);
			ps.setInt(1,Sno);
			ps.setString(2,Cno);
			  rs=ps.executeQuery();
		 	Grade grade=null;
				while(rs.next()){
					grade=new Grade();
					grade.setCno(rs.getString("Cno"));
					grade.setSno(rs.getInt("Sno"));
					grade.setName(rs.getString("name"));
					grade.setCredit(rs.getInt("credit"));
					grade.setGrade(rs.getInt("grade"));
					grade2.add(grade);
					System.out.println(grade.getCno());
					System.out.println(grade.getSno());
					System.out.println(grade.getName());
					System.out.println(grade.getCredit());
					System.out.println(grade.getGrade());	
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return grade2;
	}
	public void resumeGrade(Grade grade) throws SQLException {
		// TODO Auto-generated method stub
		conn=DBUtil.getConnection();
		String sql="update grade set name=?,credit=?,grade=? where Sno=? and Cno=? ";
		try {
			ps=conn.prepareStatement(sql);
		ps.setString(1,grade.getName());
		ps.setInt(2, grade.getCredit());
		ps.setInt(3, grade.getGrade());
		ps.setInt(4, grade.getSno());
		ps.setString(5, grade.getCno());
		}
	 catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		if(ps.executeUpdate()>0){	
			System.out.println("数据修改成功");
		}
		else{
			System.out.println("数据修改失败");
		}
		}	
  
}

