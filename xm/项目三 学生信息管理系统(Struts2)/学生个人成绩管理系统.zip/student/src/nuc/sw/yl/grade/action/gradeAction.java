package nuc.sw.yl.grade.action;



import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;










import nuc.sw.yl.grade.Dao.gradeDao;
import nuc.sw.yl.vo.Grade;


import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class gradeAction extends ActionSupport implements ModelDriven<Grade> {
	private List<Grade> grades=new ArrayList<Grade>();
	private List<Grade> grade1=new ArrayList<Grade>();
	private List<Grade> grade2=new ArrayList<Grade>();
	private Grade grade=new Grade();
	gradeDao gDao= new gradeDao();
	public Grade getModel() {
		// TODO Auto-generated method stub
		return grade;
	}
	public String addGradeMethod() throws Exception{
		gDao.addGrade(grade);
		return "addGradeOK";
	}
	public String findAllGradeMethod(){
		grades = gDao.findAllGrade();
		ActionContext.getContext().getSession().put("grades",grades);
		return "findAllGradeOk";
		
	}
		public List<Grade> getGrades() {
		return grades;
	}

	public void setGrades(List<Grade> grades) {
		this.grades = grades;
	}
	public String findSingnalGradeMethod() throws IOException{
		grade1 = gDao.findAllGradeBySno(grade.getSno());
		ActionContext.getContext().getSession().put("grade1",grade1);
		return "findSingnalGradeOk";
	}
	public List<Grade> getGrade1() {
		return grade1;
	}

	public void setGrade1(List<Grade> grade1) {
		this.grade1 = grade1;
	}
	public String deleteGradeMethod() throws Exception{
		gDao.deleteGrade(grade.getSno());
		return "deleteGradeOK";
	}
	public String findAllGradeBySnoAndCnoMethod() throws IOException{
		grade2= gDao.findAllGradeBySnoAndCno(grade.getSno(),grade.getCno());
		ActionContext.getContext().getSession().put("grade2",grade2);
		return "findSingnalGradeBySnoAndCnoOk";
	}
	public List<Grade> getGrade2() {
		return grade2;
	}

	public void setGrade2(List<Grade> grade2) {
		this.grade2 = grade2;
	}
	public String resumeaddGradeMethod() throws IOException, SQLException{
		gDao.resumeGrade(grade);
		gDao.findAllGradeBySno(grade.getSno());
		return "resumeGradeOk";
	}
}
