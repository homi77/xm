// main.js
import Vue from 'vue'
import VueRouter from 'vue-router'
import App from './App'
Vue.use(VueRouter)
// 默认在点击和 click事件触发之间有300ms的延迟
// fastclick 可以避免移动端浏览器点击延迟
import FastClick from 'fastclick'
// 设置作用范围
FastClick.attach(document.body)

import {Actionsheet,AlertPlugin} from 'vux'
// 插件 使用弹窗
Vue.use(AlertPlugin)
// 注册为全局组件
Vue.component('Actionsheet',Actionsheet)

import axios from 'axios';
Vue.prototype.http = axios;



// 导入css
import './assets/base.css'
import './assets/font-awesome-4.7.0/css/font-awesome.css'



import Outs from './components/Outs.vue'
import Findings from './components/Findings.vue'
import Orders from './components/Orders.vue'
import Mine from './components/Mine.vue'
import LocalItem from './components/LocalItem.vue'
import WeaItem from './components/WeaItem.vue'
import HotItem from './components/HotItem.vue'
import SliderItem from './components/SliderItem.vue'
import ShopItem from './components/ShopItem.vue'
const routes = [   
  { path: '/outs', component: Outs },
  { path: '/findings', component: Findings },
  { path: '/orders', component: Orders },
  { path: '/mine', component: Mine },
  { path: '/local', component: LocalItem },
  { path: '/wea', component: WeaItem },
  { path: '/hot', component: HotItem },
  { path: '/slider', component: SliderItem },
  { path: '/shop', component: ShopItem }

]

const router = new VueRouter({
  routes
})
router.push('/outs')

// 创建vue 实例
new Vue({
  router,
  render: h => h(App)
}).$mount('#app-box')


var html = document.documentElement;
var calcRem = function(){
  var w = html.clientWidth; 
  if (w <= 320) {
    html.style.fontSize = '10px';
  }else if (w <= 640) {
    html.style.fontSize = w/32 + 'px';
  }else{
    html.style.fontSize = '20px';
  }
  console.log('w='+w+' fontsize='+html.style.fontSize);
}
calcRem();
window.onresize = function(){
  calcRem();
}