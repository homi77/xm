<!-- app.vue -->
<template>
  <div id="app">
    <transition name="tabbar">
      <tabbar style="position:fixed;">
        <tabbar-item selected link="/outs">
          <img slot="icon" src="./assets/index1.png">
          <span slot="label">外卖</span>
        </tabbar-item>
        <tabbar-item link="/findings">
          <img slot="icon" src="./assets/index2.png">
          <span slot="label">发现</span>
        </tabbar-item>
        <tabbar-item link="/orders">
          <img slot="icon" src="./assets/index3.png">
          <span slot="label">订单</span>
        </tabbar-item>
        <tabbar-item link="/mine">
          <img slot="icon" src="./assets/index3.png">
          <span slot="label">我的</span>
        </tabbar-item>
      </tabbar>
    </transition>
    <router-view></router-view>
  </div>
  
</template>

<script>
import {Tabbar,TabbarItem} from 'vux'
import bus from './bus.js'
export default {
  name: 'app',
  components: {
    Tabbar,TabbarItem
  }
}
</script>

<style lang="less">
@import '~vux/src/styles/reset.less';

body {
  background-color: #fbf9fe;
  /* padding: 64px 0 50px 0; */
}


</style>
