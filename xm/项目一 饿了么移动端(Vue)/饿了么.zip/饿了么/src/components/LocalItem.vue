<template>
	<div class="local-item">
		<span class="local">{{local.name}}</span>
	</div>
</template>

<script>
	export default {
	    name:'local-item',
	    props:['local']
	    
	}
</script>

<style scoped>
.lcoal-item{
    float: left;
    width: 14.5rem;
    height: 10rem;
    margin: 0.5rem;
    font-size: 1.2rem;
}
.local{
	margin: 0 .133333rem;
	font-size: .453333rem;
	max-width: 80%;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}
</style>