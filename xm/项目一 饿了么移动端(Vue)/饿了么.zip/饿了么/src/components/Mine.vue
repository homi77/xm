<template>
    <div class="mine">
        <header></header>
    </div>
</template>

<script>
import {Group, Cell} from 'vux'
export default {
    name:'mine',
    components: {
        Group,Cell
    }
}
</script>