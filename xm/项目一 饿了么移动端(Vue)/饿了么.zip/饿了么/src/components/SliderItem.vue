<template>
	<div class="slider-item">
		
		<div v-for="item in slider.entries" style="z-index: 77777;">
				<a>
					<div class="container">
						<img :src="item.image_hash | img" alt="" />
					</div>
					<span class="name">{{item.name}}</span>
				</a>
		</div>
	    <swiper :list="demo03_list" auto style="width:100%;margin:0 auto;" height="180px" dots-class="custom-bottom" dots-position="center">
	    	
	    </swiper>
	    <br/>

	</div>
</template>

<script>
	import Vue from 'vue'
	import { Swiper, GroupTitle, SwiperItem, XButton, Divider } from 'vux'
	
	const imgList = [
	  'http://placeholder.qiniudn.com/800x300/FF3B3B/ffffff',
	  'http://placeholder.qiniudn.com/800x300/FFEF7D/ffffff'
	]
	
	const demoList = imgList.map((one, index) => ({
	  url: 'javascript:',
	  img: one
	}))
	
	
	// 图片过滤器
	Vue.filter('img',value=>{
	    var str = value.toString();
	    if (str.substring(str.length-3,str.length) == 'png') {
	    	return 'https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(1,3)+'/'+str.substring(3,35)+'.'+str.substring(str.length-3,str.length);
	    	// console.log('https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(2,4)+'/'+str.substring(5,35)+'.'+str.substring(str.length-3,str.length));
	    } else{
	    	return 'https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(1,3)+'/'+str.substring(3,36)+'.'+str.substring(str.length-4,str.length);
	    	// console.log('https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(2,4)+'/'+str.substring(5,36)+'.'+str.substring(str.length-4,str.length));
	    }

		// console.log('https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(1,3)+'/'+str.substring(3,36)+'.'+str.substring(str.length-4,str.length));
	});
	export default {
	    name:'slider-item',
	    props:['slider'],
	    components:{
	    	Swiper,
		    SwiperItem,
		    GroupTitle,
		    XButton,
		    Divider
	    },
		ready () {
	
	    },
	    data () {
		    return {
		      demo03_list: demoList,
		      swiperItemIndex: 1
		    }
		  }
			    
	}
</script>

<style scoped>
	a{
		position: relative;
		float: left;
		margin-top: .793333rem;
		width: 25%;
	}
	.container {
	    position: relative;
	    display: inline-block;
	    width: 3.45rem;
	    height: 3.45rem;
	}
	.container img{
		width: 100%;
		height: 100%;
	}
	.name{
		display: block;
		margin-top: .133333rem;
		color: #666;
		font-size: .32rem;
	}
</style>