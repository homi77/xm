<template>
    <div class="outs">
        <header>
        	<div class="title">
        		<div class="header">
	        		<span class="fa fa-map-marker"></span>
	        		<local-item :local="locallist"></local-item>
	        		<span class="fa fa-sort-desc"></span>
	        	</div>
	        	<div class="weather">
	        		<div>
	        			<wea-item :wea="wealist"></wea-item>	
	        		</div>
	        	</div>
        	</div>
        </header>
        <div class="search-wrapper" style="position: sticky;top: 0;z-index: 999;height: 4rem;">
        	<div style="top: 0;z-index: 999;height: 4rem;" class="search">
        		<a class="content">
        			<span class="fa fa-search"></span>
        			<span style="font-family: simsun;">搜索商家、商品名称</span>
        		</a>
        	</div>
        </div>
        <div class="keyword-title">
        	<div class="keyword">
        		<hot-item v-for="item in hotlist" :hot="item" :key="item.word"></hot-item>
        	</div>
        </div>
        <section>
        	<div>
        		<div class="foodentry">
        	    	<slider-item v-for="item in sliderlist" :slider="item" :key=""></slider-item>
        		</div>
        	</div>
        </section>
        <section style=" background-color: #fff;">
        	<div>
        		<section style="text-align: center;margin-bottom: .08rem;">
        			<img src="../assets/05997b77c8cb8adf82298b8a39434png.png" class="newuser"/>
        		</section>
        	</div>
        </section>
        <section style=" background-color: #fff;">
        	<div class="index-3xb2n_0">
        		<div class="index-Q3GS5 index-3OXHZ">
        			<h3 class="index-1qvn6_0">限量抢购</h3>
        			<div class="index-2w67h_0">超值美味 9.9元起</div>
        			<div class="index-1dfa7_0" style="color: #333;">
        				<span>5人</span>
        				正在抢 >
        			</div>
        			<img src="../assets/0fa0ed514c093a7138b0b9a50d61fpng.png" alt="" />
        		</div>
        		<div class="index-Q3GS5">
        			<h3 class="index-1qvn6_0">热卖套餐</h3>
        			<div class="index-2w67h_0">销量最高，好评最多</div>
        			<div class="index-1dfa7_0">
        				TOP 100 >
        			</div>
        			<img src="../assets/16ff085900d62b8d60fa7e9c6b65dpng.png" alt="" />
        		</div>
        	</div>
        	<div class="index-QE-ye_0">
        		<div class="index-Q3GS5">
        			<h3 class="index-1qvn6_0">天天特价</h3>
        			<span class="index-2w67h_0" style="color: #ff5339;border-color: #ffa89b;">低至1折</span>
        			<img src="../assets/ddb537220b8c56d4ef6ae22718984png.png" alt="" />
        		</div>
        		<div class="index-Q3GS5">
        			<h3 class="index-1qvn6_0">吃货狂欢</h3>
        			<span class="index-2w67h_0">随叫随到</span>
        			<img src="../assets/8010e87e876a7bf137597bf7fd324png.png" alt="" />
        		</div>
        		<div class="index-Q3GS5">
        			<h3 class="index-1qvn6_0">品质优选</h3>
        			<span class="index-2w67h_0">尖货来袭</span>
        			<img src="../assets/dcb5bff74242e06b3c2efee1cbffcpng.png" alt="" />
        		</div>
        	</div>
        </section>
        
        <!--推荐商家-->
        
        <h3 class="index-title">推荐商家</h3>
        
        <!--下面依次是商家-->
        
        <section class="shoplist">
        	<section class="index-container_10L_lQb">
        		<shop-item v-for="item in shoplist" :shop="item" :key="item.authentic_id"></shop-item>
        	</section>
        </section>
        
        <section style="height: 500px;"></section>
    </div>
</template>

<script>
import LocalItem from './LocalItem'
import WeaItem from './WeaItem'
import HotItem from './HotItem'
import SliderItem from './SliderItem'
import ShopItem from './ShopItem'
export default {
    name:'outs',
	components: {
	    LocalItem,WeaItem,HotItem,SliderItem,ShopItem
    },
    data(){
        return {
            status:'loading',
            locallist:{},
            wealist:[],
            hotlist:[],
            sliderlist:[],
            shoplist:[]
            // isLoading: false
        }
    },
    methods: {
        loadMore(){
            // this.isLoading = true;
            this.http.get('/elmapi/v2/pois/ww8p3nhuhtsh',{
                params:{offset:this.locallist.length/30}
            })
            .then(res=>{
                if (res.data.error == 0) {
                    this.locallist = this.locallist.concat(res.data);
                }
                // this.isLoading = false;
            },err=>{
                // this.isLoading = false;   
            });
            // this.isLoading = true;
            this.http.get('/elmapi/bgs/weather/current?latitude=37.87059&longitude=112.550667',{
                params:{offset:this.wealist.length/30}
            })
            .then(res=>{
                if (res.data.error == 0) {
                	
                    this.wealist = this.wealist.concat(res.data);
                }
                // this.isLoading = false;
            },err=>{
                // this.isLoading = false;   
            });
            // this.isLoading = true;
            this.http.get('/elmapi/shopping/v3/hot_search_words?latitude=37.87059&longitude=112.550667',{
                params:{offset:this.hotlist.length/30}
            })
            .then(res=>{
                if (res.data.error == 0) {
                	
                    this.hotlist = this.hotlist.concat(res.data);
                }
                // this.isLoading = false;
            },err=>{
                // this.isLoading = false;   
            });
            // this.isLoading = true;
            this.http.get('/elmapi/shopping/v2/entries?latitude=37.87059&longitude=112.550667&templates[]=main_template',{
                params:{offset:this.sliderlist.length/30}
            })
            .then(res=>{
                if (res.data.error == 0) {
                	
                    this.sliderlist = this.sliderlist.concat(res.data);
                }
                // this.isLoading = false;
            },err=>{
                // this.isLoading = false;   
            });
            // this.isLoading = true;
            this.http.get('/elmapi/shopping/restaurants?latitude=37.87059&longitude=112.550667&offset=0&limit=20&extras[]=activities&terminal=h5&extra_filters=home',{
                params:{offset:this.shoplist.length/30}
            })
            .then(res=>{
                if (res.data.error == 0) {
                	
                    this.shoplist = this.shoplist.concat(res.data);
                }
                // this.isLoading = false;
            },err=>{
                // this.isLoading = false;   
            });
        }
    },
    mounted () {
        window.onscroll = this.didScroll;
        console.log('获取房间列表');
        this.http.get('/elmapi/v2/pois/ww8p3nhuhtsh').then(res=>{
            if (res.data) {
                this.status = 'success';
                this.locallist = res.data;
                // console.log(this.locallist);
            } else {
                this.status = 'fail';
            }
        },err=>{
            console.log(err);
            this.status = 'fail'
        });
        this.http.get('/elmapi/bgs/weather/current?latitude=37.87059&longitude=112.550667').then(res=>{
            if (res.data) {
                this.status = 'success';
                this.wealist = res.data;
                console.log(this.wealist);
            } else {
                this.status = 'fail';
            }
        },err=>{
            console.log(err);
            this.status = 'fail'
        });
        this.http.get('/elmapi/shopping/v3/hot_search_words?latitude=37.87059&longitude=112.550667').then(res=>{
            if (res.data) {
                this.status = 'success';
                this.hotlist = res.data;
                // console.log(JSON.stringify(this.roomlist));
                // console.log(this.hotlist);
            } else {
                this.status = 'fail';
            }
        },err=>{
            console.log(err);
            this.status = 'fail'
        });
        this.http.get('/elmapi/shopping/v2/entries?latitude=37.87059&longitude=112.550667&templates[]=main_template').then(res=>{
            if (res.data) {
            	// console.log(res.data);
                this.status = 'success';
                this.sliderlist = res.data;
                // console.log(JSON.stringify(this.roomlist));
                // console.log(this.sliderlist);
            } else {
                this.status = 'fail';
            }
        },err=>{
            console.log(err);
            this.status = 'fail'
        });
        this.http.get('/elmapi/shopping/restaurants?latitude=37.87059&longitude=112.550667&offset=0&limit=20&extras[]=activities&terminal=h5&extra_filters=home').then(res=>{
            if (res.data) {
            	// console.log(res.data);
                this.status = 'success';
                this.shoplist = res.data;
                // console.log(JSON.stringify(this.roomlist));
                console.log(this.shoplist);
            } else {
                this.status = 'fail';
            }
        },err=>{
            console.log(err);
            this.status = 'fail'
        });
    }
}
</script>

<style scoped>
header{
	padding: .266667rem .373333rem 0;
	background-image: linear-gradient(90deg,#0af,#0085ff);
	color: white;
	font-size: 1.5rem;
}
.title{
	display: flex;
	justify-content: space-between;
	align-items: center;
	height: 2.65rem;
}
.header{
	display: flex;
	align-items: center;
	width: 60%;
	font-weight: 700;
}

.fa-sort-desc{
	width: .186667rem;
	height: .093333rem;
	fill: #fff;
	font-size: 12px;
}
.weather{
	align-items: center;
	text-align: right;
	display: flex;
}

.wIcon{
	margin-left: .106667rem;
	width: .733333rem;
	height: .733333rem;
	max-width: 100%;
}
.search{
	padding: .8rem .873333rem;
	margin: -.013333rem 0;
	background-image: linear-gradient(90deg,#0af,#0085ff);
	text-align: center;
}
.content{
	display: flex;
	width: 100%;
	height: 2.5rem;
	align-items: center;
	border-radius: .026667rem;
	background: #fff;
	color: #666;
	font-size: .346667rem;
	font-weight: 700;
	margin-top: 0;
	
}
.fa-search{
	display: inline-block;
    width: .32rem;
    height: .32rem;
    margin-right: 1.133333rem;
}
.search-wrapper{
	background-image: linear-gradient(90deg,#0af,#0085ff);
	width: 100%;
	/*height: 5rem;*/
}
.keyword-title{
	height: 2.96rem;
	padding: .6rem .773333rem .4rem;
	background-image: linear-gradient(90deg,#0af,#0085ff);
}
.keyword{
	width: 100%;
	height: 1.3rem;
	color: #fff;
	white-space: nowrap;
	overflow-x: auto;
	overflow: hidden;
}

.foodentry{
	width: 100%;
	overflow: hidden;
	height: 14.72rem;
	background-color: #fff;
	text-align: center;
}
.newuser{
	width: 26.8rem;
	height: 6.7rem;
	margin-left: .106667rem;
	max-width: 100%;
}
.index-3xb2n_0{
	margin-bottom: .08rem;
	display: flex;
	padding: 0.166667rem 0.766667rem;
}
.index-Q3GS5{
	margin-right: .08rem;
	height: 9.733333rem;
	padding: .32rem 0 0 .4rem;
	z-index: 1;
	position: relative;
	-webkit-box-flex: 1;
	flex: 1;
	background: linear-gradient(0deg,#f4f4f4 5%,#fafafa 95%);
}
.index-1qvn6_0{
	font-size: 1.653333rem;
	font-weight: 700;
	/*margin-bottom: .133333rem;*/
	color: #333;
}
.index-2w67h_0{
	font-size: .546667rem;
	color: #777;
	margin-bottom: .44rem;
}
.index-3xb2n_0 .index-Q3GS5 .index-1dfa7_0{
	font-size: .42rem;
	color: #af8260;
	font-weight: 700;
}
.index-1dfa7_0 span{
    color: #e81919;
}
.index-3xB2N_0 .index-3OXHZ .index-1dfa7_0{
    color: #333;
}
.index-Q3GS5 img{
	position: absolute;
	right: 0;
	bottom: -.2rem;
	width: 9.2rem;
	height: 6.133333rem;
	max-width: 100%;
}
.index-Q3GS5 .index-1qvn6_0{
	font-size: 1.553333rem;
	font-weight: 700;
	margin-bottom: .653333rem;
}
.index-3OXHZ .index-1qvn6_0{
	color: #e81919;
}
.index-QE-ye_0 {
    padding-bottom: .28rem;
    display: flex;
    padding: 0.116667rem 0.766667rem;
    margin-bottom: 0.5rem;
}
.index-3xb2n_0 .index-Q3GS5, .index-QE-ye_0 .index-Q3GS5{
    flex: 1;
    background: linear-gradient(0deg,#f4f4f4 5%,#fafafa 95%);
}
.index-QE-ye_0 .index-Q3GS5{
    height: 10.186667rem;
    text-align: center;
    position: relative;
}
.index-QE-ye_0 .index-Q3GS5 img{
	position: absolute;
	width: 8.893333rem;
	height: 5.853333rem;
	bottom: 0;
	left: 0;
}
.index-QE-ye_0 .index-Q3GS5 .index-1qvn6_0{
	font-size: 1.52667rem;
	font-weight: 700;
	color: #333;
	margin: .826667rem 0 .133333rem;
	margin-bottom: 0.85rem;
}
.index-QE-ye_0 .index-Q3GS5 .index-2w67h_0{
	text-align: center;
	padding: 0 .153333rem;
	font-size: .153333rem;
	color: #777;
	border-radius: .026667rem;
	border: 1px solid #bbb;
}
.index-title {
    margin-top: .966667rem;
    font-weight: 600;
    background-color: #fff;
    border-top: 1px solid #eee;
    font-size: 1.356667rem;
    padding: .96667rem .966667rem 0;
    line-height: 1.4rem;
}
.shoplist{
    background-color: #fff;
    background-size: 100% auto;
}
.index-container_10L_lQb{
    position: relative;
    border-bottom: 1px solid #eee;
    background-color: #fff;
    color: #666;
    padding: .4rem 0;
    list-style: none;
    font-size: .293333rem;
    line-height: normal;

}
</style>