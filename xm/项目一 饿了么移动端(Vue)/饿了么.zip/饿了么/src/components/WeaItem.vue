<template>
	<div class="wea-item">
		<div>
			<h2 class="tem">{{wea.temperature+'°'}}</h2>
			<p class="wea">{{wea.description}}</p>
		</div>
		<img :src="wea.image_hash | img" alt="" style=""/>
	</div>
</template>

<script>
	import Vue from 'vue'

	Vue.filter('img',value=>{
	    var str = value.toString();
	    if (str.substring(str.length-3,str.length) == 'png') {
	    	return 'https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(1,3)+'/'+str.substring(3,35)+'.'+str.substring(str.length-3,str.length);
	    	// console.log('https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(2,4)+'/'+str.substring(5,35)+'.'+str.substring(str.length-3,str.length));
	    } else{
	    	return 'https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(1,3)+'/'+str.substring(3,36)+'.'+str.substring(str.length-4,str.length);
	    	// console.log('https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(2,4)+'/'+str.substring(5,36)+'.'+str.substring(str.length-4,str.length));
	    }
//console.log('https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(1,3)+'/'+str.substring(3,36)+'.'+str.substring(str.length-4,str.length));
	});
	export default {
	    name:'wea-item',
	    props:['wea']
	    
	}
</script>

<style scoped>
.wea-item{
    display: flex;
    align-items: center;
    text-align: right;
}
.tem{
	font-size: .373333rem;
}
.wea{
	font-size: .266667rem;
}
img{
	margin-left: .106667rem;
	width: 2.133333rem;
	height: 2.133333rem;
}
</style>