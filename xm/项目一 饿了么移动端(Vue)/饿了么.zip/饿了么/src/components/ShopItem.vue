<template>
	<div class="shop-item">
		<div class="index-shopInfo_1RRTZ0d">
			<div class="logo-container_XoH2Vit_0">
				<div class="logo-main_21aInWJ_0">
					<img :src="shop.image_path | img" alt="" class="logo-logo_3S1eSkn_0"/>
				</div>
			</div>
			<div class="index-main_N3FfcSz">
				<section class="index-line_2-iYR1A">
					<h3 class="index-shopname_39Y7e3U">
						<span>{{shop.name}}</span>
					</h3>
					<ul class="index-supportWrap_2lTcxr2"></ul>
				</section>
				<section class="index-line_2-iYR1A">
					<div class="index-rateWrap_39dWx_g">
						<!--评分-->
						<div class="Rating-wrapper_TYbDrku_0" style="margin-top: -2rem;">
							<group style="margin: 0; padding: 0;">
						      <cell>
						        <rater v-model="shop.rating" :font-size="15" disabled></rater>
						      </cell>
						    </group>
						</div>
						<!--分数-->
						<span class="index-rate_WsK58g8">{{shop.rating}}</span>
						<!--月售-->
						<span>月售{{shop.recent_order_num}}单</span>
					</div>
				</section>
				<section class="index-line_2-iYR1A" style="display: block;">
					<div class="index-moneylimit_2fCq9W5" style="float: left;">
						<!--起送费-->
						<span>￥{{shop.float_minimum_order_amount}}起送</span>
						<span style="color: #999;margin: 0 0.2rem;">|</span>
						<!--运费-->
						<span>{{shop.piecewise_agent_fee.tips}}</span>
					</div>
					<div class="index-timedistanceWrap_2Dp_kzY" style="float: right;">
						<!--距离-->
						<span>{{shop.distance | distance}}</span>
						<span style="color: #999;margin: 0 0.2rem;">|</span>
						<!--时间-->
						<span>{{shop.order_lead_time}}分钟</span>
					</div>
				</section>
			</div>
		</div>
		<div class="index-activityWrap_3mo1GyG">
			<section class="index-recommend_1Ro4u5J" style="display: inline-block;">
				<!--认证-->
				<span class="index-sourceTag_32NKya6" style="color: rgb(232,71,11);">
					<!--图标-->
					<img :src="shop.recommend.image_hash | img" alt="" style="margin-right:0.2rem;width: 0.76rem;height: 0.76rem;"/>
					<span>{{shop.recommend.reason}}</span>
				</span>
			</section>
			<span class="index-dashedline_7B79b3W"></span>
			<section class="index-activities_25AUDsx">
				<div class="index-activityList_1wvwwUY">
					<div class="ndex-actRow_2f_uNNA" v-for="item in shop.activities">
						<!--首单-->
						<span class="index-iconWrap_1xJuKaY">
							<!--图标-->
							<span class="index-icon_1fBCxBk" style="background-color: rgb(112,188,70);color:#fff ;line-height: 1.7rem;height: 1rem;">{{item.icon_name}}</span>
						</span>
						<!--首单活动-->
						<span class="index-desc_JLha7Vr">{{item.tips}}</span>
					</div>
				</div>
				<div class="index-activityBtn_tMk-e1C">
					{{shop.activities.length | number}}个活动
					<span class="fa fa-sort-down"></span>
				</div>
			</section>
		</div>
	</div>
</template>

<script>
	import Vue from 'vue'
	import { Rater, Group, Cell, Range } from 'vux'

	Vue.filter('distance',value=>{
	    if (value >= 1000) {
	        return (value/1000).toFixed(2)+'km'
	    } else {
	        return value;
	    }
	});
//	Vue.filter('activities',value=>{
//		console.log(value);
//		
//	    Vue.filter('number',num=>{
//	    	console.log('************************')
//	    	console.log(value);
//	    	console.log(num);
//	    });
//	});
//	Vue.filter('activities',value=>{
//  	for (var i = 0; i < value.length; i++) {
//  		return value[0]+value[1];
//  	}
//  });
	Vue.filter('img',value=>{
	    var str = value.toString();
	    if (str.substring(str.length-3,str.length) == 'png') {
	    	return 'https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(1,3)+'/'+str.substring(3,35)+'.'+str.substring(str.length-3,str.length);
	    	// console.log('https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(2,4)+'/'+str.substring(5,35)+'.'+str.substring(str.length-3,str.length));
	    } else{
	    	return 'https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(1,3)+'/'+str.substring(3,36)+'.'+str.substring(str.length-4,str.length);
	    	// console.log('https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(2,4)+'/'+str.substring(5,36)+'.'+str.substring(str.length-4,str.length));
	    }
//console.log('https://fuss10.elemecdn.com/'+str.substring(0,1)+'/'+str.substring(1,3)+'/'+str.substring(3,36)+'.'+str.substring(str.length-4,str.length));
	});
	export default {
		components: {
		    Rater,
		    Group,
		    Cell,
		    Range
		},
	    name:'shop-item',
	    props:['shop']
	    
	}
</script>

<style scoped>
	.shop-item{
		position: relative;
	    border-bottom: 1px solid #eee;
	    background-color: #fff;
	    color: #666;
	    padding: .4rem 0;
	    list-style: none;
	    font-size: .293333rem;
	    line-height: normal;
	}
	.index-shopInfo_1RRTZ0d {
	    display: flex;
	    justify-content: flex-start;
	    align-items: stretch;
	    padding: 0.763667rem;
	    overflow: hidden;
	}
	.logo-container_XoH2Vit_0 {
	    position: relative;
	    flex: none;
	}
	.logo-main_21aInWJ_0 {
	    position: relative;
	    width: 4.973333rem;
	    height: 4.973333rem;
	}
	.logo-logo_3S1eSkn_0 {
	    box-sizing: border-box;
	    display: block;
	    width: 100%;
	    height: 100%;
	    border-radius: .053333rem;
	    border: 1px solid rgba(0,0,0,.08);
	}
	img {
	    max-width: 100%;
	}
	.index-main_N3FfcSz {
	    flex-grow: 1;
	    flex-direction: column;
	    user-select: none;
	    padding-left: .716667rem;
	}
	.index-line_2-iYR1A, .index-shopname_39Y7e3U {
	    align-items: center;
	}
	.index-line_2-iYR1A, .index-main_N3FfcSz {
	    display: flex;
	    justify-content: space-between;
	    overflow: hidden;
	}
	.index-shopname_39Y7e3U {
	    display: flex;
	    margin: 0;
	    padding: 0;
	    color: #333;
	    font-weight: 700;
	    font-size: 1.4rem;
	    overflow: hidden;
	}
	.index-shopname_39Y7e3U span {
	    overflow: hidden;
	    text-overflow: ellipsis;
	    white-space: nowrap;
	    font-size: 1.28rem;
	    line-height: 1.4rem;
	}
	.index-supportWrap_2lTcxr2 {
    	margin-left: .266667rem;
	}
	.index-rateWrap_39dWx_g {
	    display: flex;
	    align-items: center;
	    font-size: 0.5rem;
	}
	.index-rateWrap_39dWx_g span{
		font-size: 0.2rem;
	}
	.Rating-wrapper_TYbDrku_0 {
	    position: relative;
	    overflow: hidden;
	    display: inline-block;
	    vertical-align: middle;
	    height: ;
	}
	.index-rate_WsK58g8 {
	    margin: 0 .306667rem;
	}
	.index-moneylimit_2fCq9W5 {
	    display: flex;
	    align-content: center;
	}
	.index-moneylimit_2fCq9W5 span:nth-of-type(2) {
	    overflow: hidden;
	    max-width: 7.066667rem;
	    text-overflow: ellipsis;
	    white-space: nowrap;
	}
	.index-timedistanceWrap_2Dp_kzY {
	    display: flex;
	    align-items: center;
	    color: #999;
	}
	.index-activityWrap_3mo1GyG {
    	padding-left: 6.266667rem;
	}
	.index-recommend_1Ro4u5J {
	    margin: .266667rem .266667rem 0 0;
	}
	.index-sourceTag_32NKya6 {
	    display: flex;
	    align-items: center;
	    font-size: .266667rem;
	}
	.index-dashedline_7B79b3W {
	    width: 100%;
	    height: .4rem;
	    padding-right: .266667rem;
	}
	.index-activities_25AUDsx {
	    position: relative;
	    justify-content: space-between;
	    align-content: stretch;
	    overflow: hidden;
	}
	.index-activityList_1wvwwUY {
	    flex: 1;
	    padding-right: .266667rem;
	    overflow: hidden;
	}
	.index-actRow_2f_uNNA {
	    display: flex;
	    align-items: center;
	    font-size: .293333rem;
	    line-height: .48rem;
	}
	.index-activities_25AUDsx, .index-supportWrap_2lTcxr2 {
	    display: flex;
	}
	.index-actRow_2f_uNNA .index-iconWrap_1xJuKaY {
	    position: relative;
	    margin-right: .16rem;
	    height: .373333rem;
	    width: .373333rem;
	}
	.index-actRow_2f_uNNA .index-icon_1fBCxBk {
	    position: absolute;
	    left: 0;
	    top: 0;
	    z-index: 1;
	    height: .746667rem;
	    width: .746667rem;
	    font-size: .56rem;
	    color: #fff!important;
	    display: flex;
	    align-items: center;
	    justify-content: center;
	    border-radius: .106667rem;
	    transform: scale(.5);
	    transform-origin: 0 0;
	}
	.index-actRow_2f_uNNA .index-desc_JLha7Vr {
	    flex: 1;
	    overflow: hidden;
	    white-space: nowrap;
	    text-overflow: ellipsis;
	}
	.index-activityBtn_tMk-e1C {
	    padding: .08rem .266667rem 0 0;
	    color: #999;
	    text-align: right;
	    font-size: .266667rem;
	    line-height: 1;
	}
	.index-activityBtn_tMk-e1C span {
	    width: .173333rem;
	    height: .173333rem;
	    opacity: .9;
	    margin-left: .026667rem;
	    transition: all .3s ease-in-out;
	    transform: rotate(0);
	    fill: currentColor;
	    will-change: transform;
	}
	.weui-cell{
		padding: 0;
	}
</style>