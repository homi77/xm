<template>
	<div class="hot-item">
		<a>{{hot.word}}</a>
	</div>
</template>

<script>
	export default {
	    name:'hot-item',
	    props:['hot']
	    
	}
</script>

<style scoped>
.hot-item{
	/*overflow: hidden;*/
}
a{
	margin-right: 1.2rem;
	color: currentColor;
	float: left;
	font-size: 12px;
	line-height: 1.2rem;
	margin-top: 0;
}
</style>