<template>
    <div class="findings">
        <header></header>
    </div>
</template>

<script>
export default {
    name:'findings'
    
}
</script>