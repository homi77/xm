
// 登录成功显示名字到首页
var username = $.cookie("username");

// 判断 username 有没有值，改变 user 的样式和行为
if (username) {
	$(".nav-list li").eq(0).text(username);
} else{
	$(".nav-list li").eq(0).text("你好，请登录").click(function(){
		location.href = "login.html";
	});
}

//我的京东下拉菜单
$("#myJD").hover(
	function(){
		$(".myJD").css("display","block");
		$("#myJD").addClass("showList");
	},
	function(){
		$(".myJD").css("display","none");
		$("#myJD").removeClass("showList");
	}
);
//$(".myJD").hover(
//	function(){
//		$(".myJD").css("display","block");
//		$("#myJD").addClass("showList");
//	},
//	function(){
//		$(".myJD").css("display","none");
//		$("#myJD").removeClass("showList");
//	}
//);
// 顾客服务下拉菜单
$("#customServe").hover(
	function(){
		$(".customServe").css("display","block");
		$("#customServe").addClass("showList");
	},
	function(){
		$(".customServe").css("display","none");
		$("#customServe").removeClass("showList");
	}
);
//$(".customServe").hover(
//	function(){
//		$(".customServe").css("display","block");
//		$("#customServe").addClass("showList");
//	},
//	function(){
//		$(".customServe").css("display","none");
//		$("#customServe").removeClass("showList");
//	}
//);
// 定位下拉菜单
$("#location").hover(
	function(){
		$(".location").css("display","block");
		$("#location").addClass("showList");
	},
	function(){
		$(".location").css("display","none");
		$("#location").removeClass("showList");
	}
);
$(".location").hover(
	function(){
		$(".location").css("display","block");
		$("#location").addClass("showList");
	},
	function(){
		$(".location").css("display","none");
		$("#location").removeClass("showList");
	}
);
// 网页导航下拉菜单
$("#guide").hover(
	function(){
		$(".guide").css("display","block");
		$("#guide").addClass("showList");
	},
	function(){
		$(".guide").css("display","none");
		$("#guide").removeClass("showList");
	}
);


// 轮播图
var $img_a = $(".banner .img .banner_img_a");
var $indicator = $(".indicator div");

// 表示当前轮播到第几张图片了
var index = 0;

// 开启自动轮播
var interval = setInterval(changeIndex,3000);

// 改变 index
function changeIndex(){
	// 获取下一张索引
	index = index >= $img_a.length - 1 ? 0 : index+1;
	// 切换图片
	changeImage();
}

// 切换图片
function changeImage(){
	$img_a.eq(index).fadeIn("fast").siblings().fadeOut("fast");
	$indicator.eq(index).addClass("cur").siblings().removeClass("cur");
}

// 当鼠标移到页标指示器上
$indicator.hover(function(){
	// 停止自动轮播
	clearInterval(interval);
	// 获取当前鼠标移到span的索引
	index = $(this).index();
	// 切换图片
	changeImage();
},function(){
	// 继续自动轮播
	interval = setInterval(changeIndex,3000);
});

// 鼠标移到轮播图上
$(".slide").hover(
	function(){
	// 停止自动轮播
	clearInterval(interval);
},function(){
	// 继续自动轮播
	interval = setInterval(changeIndex,3000);
});

// 点击上一页
$(".page .pageLeft").click(function(){
	// 获取上一张索引
	index = index <= 0 ? $img_a.length - 1 : index-1;
	// 切换图片
	changeImage();
});
// 点击下一页
$(".page .pageRight").click(function(){
	changeIndex();
});
$(".slide").hover(
	function(){
		$(".page").css("display","block");
	},
	function(){
		$(".page").css("display","none");
	}
);

/*工具栏*/
$(".tools").each(function(index){
	var span =$(".toolText span").eq(index);
	var tool =$(".tools").eq(index);
	tool.hover(	
		function(){
			tool.addClass("hoverTool");
			span.css("display","block");
		},
		function(){
			tool.removeClass("hoverTool");
			span.css("display","none");
		}
	);
	span.hover(
		function(){
		    $(this).css("display","block");
		    tool.addClass("hoverTool");
	    },
	    function(){
	    	$(this).css("display","none");
	    	tool.removeClass("hoverTool");
	    }
    );
});

// 点击回顶部
$(".backTop").click(function(){
	$("html,body").animate({
		scrollTop: 0
	},"slow");
});


//公告栏切换
$(".middle-head-b").mouseenter(function(){
	$(".little-line").css({
		top:22,
		left:64
	});
	$(".middle-content .buy").css("display","none");
	$(".middle-content .adver").css("display","block");
});


$(".middle-head-a").mouseenter(function(){
	$(".little-line").css({
		top:22,
		left:14
	})
	$(".middle-content .buy").css("display","block");
	$(".middle-content .adver").css("display","none");
});

// 轮播搜索条
/*
// 轮播的载体
var $div_img = $(".slideList");
// 轮播到第几张图片
var index = 1;

// 自动轮播
var timer = setInterval(changeImage,3000);
function changeImage(){
	// index 递增
	index ++;
	// 自定义动画
	$div_img.finish().animate({
		left: -100*index
	},1000,function(){
		// 每次动画结束的回调函数
		if (index >= 7) {
			index = 1;
			$(this).css("left",-100);
		}
	});
}
*/

//当前轮播到第几张了
var index = 0;
var last = 4;
//上一张的index是多少？
function getIndexPrev(){
	return  index <= 0 ? $(".slideList li").length-1:index-1;
}
//下一张的index是多少？
function getIndexNext(){
	return index >= $(".slideList li").length-1 ? 0:index+1;
}
//显示图片
function showPrevImage(){
	index = getIndexPrev();
	$(".slideList li").eq(last).css({
		left: 0,
	}).finish().show().animate({
		left: 100,
	},500,function(){
		$(this).hide().css({
			left: -100,
		});
	});
	$(".slideList li").eq(index).css({
		left: -100,
	}).finish().show().animate({
		left: 0,
	},500);
	last = index;
}
function showNextImage(){
	index = getIndexNext();
	$(".slideList li").eq(last).css({
		left: 0,
	}).finish().show().animate({
		left: -100,
	},500,function(){
		$(this).hide().css({
			left: 100,
		});
	});
	$(".slideList li").eq(index).css({
		left: 100,
	}).finish().show().animate({
		left: 0,
	},500);
	last = index;
}
	//定时器轮播
	var timerInput = setInterval(showNextImage,3000);
	

// 分类展开
$(".classify-list li").hover(
	function(){
		$(".classify-list-menu").css("display","block");
		$(this).toggleClass("menu-style");
	},
	function(){
		$(".classify-list-menu").css("display","none");
		$(this).toggleClass("menu-style");
	}
);

// 小图标悬停
$(".telFare-title span").each(function(index){
		var $div =$(".telFare-content div").eq(index);
	    $(this).hover(
				function(){
				    $(this).addClass("telFare-hover");
				    $div.css("display","block");
			    },
			    function(){
			    	$(this).removeClass("telFare-hover");
			    	$div.css("display","none");
			    }
		);
});

$(".bottom-icon a").eq(0).mouseenter(function(){
	$(".telFare").slideDown("fast");
	$(".telFare-title-a").addClass("telFare-hover");
	$(".telFare-content-a").css("display","block");
	$(".telFare-content-a").hover(
		function(){
			$(".telFare-title-a").addClass("telFare-hover");
			$(".telFare-content-a").css("display","block");
		},
		function(){
			$(".telFare-title-a").removeClass("telFare-hover");
			$(".telFare-content-a").css("display","none");
		}
	);
	$(".telFare-content-b").hover(
		function(){
			$(".telFare-title-b").addClass("telFare-hover");
			$(".telFare-content-b").css("display","block");
		},
		function(){
			$(".telFare-title-b").removeClass("telFare-hover");
			$(".telFare-content-b").css("display","none");
		}
	);
	$(".telFare-content-c").hover(
		function(){
			$(".telFare-title-c").addClass("telFare-hover");
			$(".telFare-content-c").css("display","block");
		},
		function(){
			$(".telFare-title-c").removeClass("telFare-hover");
			$(".telFare-content-c").css("display","none");
		}
	);
	$(".telFare-content-d").hover(
		function(){
			$(".telFare-title-d").addClass("telFare-hover");
			$(".telFare-content-d").css("display","block");
		},
		function(){
			$(".telFare-title-d").removeClass("telFare-hover");
			$(".telFare-content-d").css("display","none");
		}
	);
});

$(".bottom-icon a").eq(1).mouseenter(function(){
	$(".telFare").slideDown("fast");
	$(".telFare-title-b").addClass("telFare-hover");
	$(".telFare-content-b").css("display","block");
	$(".telFare-content-a").hover(
		function(){
			$(".telFare-title-a").addClass("telFare-hover");
			$(".telFare-content-a").css("display","block");
		},
		function(){
			$(".telFare-title-a").removeClass("telFare-hover");
			$(".telFare-content-a").css("display","none");
		}
	);
	$(".telFare-content-b").hover(
		function(){
			$(".telFare-title-b").addClass("telFare-hover");
			$(".telFare-content-b").css("display","block");
		},
		function(){
			$(".telFare-title-b").removeClass("telFare-hover");
			$(".telFare-content-b").css("display","none");
		}
	);
	$(".telFare-content-c").hover(
		function(){
			$(".telFare-title-c").addClass("telFare-hover");
			$(".telFare-content-c").css("display","block");
		},
		function(){
			$(".telFare-title-c").removeClass("telFare-hover");
			$(".telFare-content-c").css("display","none");
		}
	);
	$(".telFare-content-d").hover(
		function(){
			$(".telFare-title-d").addClass("telFare-hover");
			$(".telFare-content-d").css("display","block");
		},
		function(){
			$(".telFare-title-d").removeClass("telFare-hover");
			$(".telFare-content-d").css("display","none");
		}
	);
});

$(".bottom-icon a").eq(2).mouseenter(function(){
	$(".telFare").slideDown("fast");
	$(".telFare-title-c").addClass("telFare-hover");
	$(".telFare-content-c").css("display","block");
	$(".telFare-content-a").hover(
		function(){
			$(".telFare-title-a").addClass("telFare-hover");
			$(".telFare-content-a").css("display","block");
		},
		function(){
			$(".telFare-title-a").removeClass("telFare-hover");
			$(".telFare-content-a").css("display","none");
		}
	);
	$(".telFare-content-b").hover(
		function(){
			$(".telFare-title-b").addClass("telFare-hover");
			$(".telFare-content-b").css("display","block");
		},
		function(){
			$(".telFare-title-b").removeClass("telFare-hover");
			$(".telFare-content-b").css("display","none");
		}
	);
	$(".telFare-content-c").hover(
		function(){
			$(".telFare-title-c").addClass("telFare-hover");
			$(".telFare-content-c").css("display","block");
		},
		function(){
			$(".telFare-title-c").removeClass("telFare-hover");
			$(".telFare-content-c").css("display","none");
		}
	);
	$(".telFare-content-d").hover(
		function(){
			$(".telFare-title-d").addClass("telFare-hover");
			$(".telFare-content-d").css("display","block");
		},
		function(){
			$(".telFare-title-d").removeClass("telFare-hover");
			$(".telFare-content-d").css("display","none");
		}
	);
});

$(".bottom-icon a").eq(3).mouseenter(function(){
	$(".telFare").slideDown("fast");
	$(".telFare-title-d").addClass("telFare-hover");
	$(".telFare-content-d").css("display","block");
	$(".telFare-content-a").hover(
		function(){
			$(".telFare-title-a").addClass("telFare-hover");
			$(".telFare-content-a").css("display","block");
		},
		function(){
			$(".telFare-title-a").removeClass("telFare-hover");
			$(".telFare-content-a").css("display","none");
		}
	);
	$(".telFare-content-b").hover(
		function(){
			$(".telFare-title-b").addClass("telFare-hover");
			$(".telFare-content-b").css("display","block");
		},
		function(){
			$(".telFare-title-b").removeClass("telFare-hover");
			$(".telFare-content-b").css("display","none");
		}
	);
	$(".telFare-content-c").hover(
		function(){
			$(".telFare-title-c").addClass("telFare-hover");
			$(".telFare-content-c").css("display","block");
		},
		function(){
			$(".telFare-title-c").removeClass("telFare-hover");
			$(".telFare-content-c").css("display","none");
		}
	);
	$(".telFare-content-d").hover(
		function(){
			$(".telFare-title-d").addClass("telFare-hover");
			$(".telFare-content-d").css("display","block");
		},
		function(){
			$(".telFare-title-d").removeClass("telFare-hover");
			$(".telFare-content-d").css("display","none");
		}
	);
});

// 秒杀倒计时
// 获取 span、button
var spans = document.querySelectorAll("#container span");
setInterval(updateTime,3000);

function updateTime(){
	// 获取总的时间（s），并让时间减一
	var totalSeconds = spans[0].innerHTML*3600 + spans[1].innerHTML*60 + spans[2].innerHTML*1;
	totalSeconds --;
	
	// 重新获取分钟和秒数
	var hours =Math.floor(totalSeconds / 3600);
	var minutes = Math.floor((totalSeconds-hours*3600) / 60);
	var seconds = totalSeconds % 60;
	
	// 如果时间小于10，在前面加0
//	hours = hours < 10 ? "0" + hours : hours;
//	minutes = minutes < 10 ? "0" + minutes : minutes;
//	seconds = seconds < 10 ? "0" + seconds : seconds;
	
	// 把时间显示上去
	spans[0].innerHTML = hours.toString().replace(/^(\d)$/,"0$1");
	spans[1].innerHTML = minutes.toString().replace(/^(\d)$/,"0$1");
	spans[2].innerHTML = seconds.toString().replace(/^(\d)$/,"0$1");
}


// 定位
$(".location div").eq(0).find("a").addClass("location-click");
//$(".location div").find("a").addClass("location-hover");
$(".location div").each(function(index){
	
	$(this).click(function(){
//		$(".location div").find("a").removeClass("location-hover");
		$(".location div").find("a").removeClass("location-click");
		$(this).find("a").addClass("location-click");
		$(".local").text($(this).text());
	});
});


//滚动时出现导航栏
//if($(document).scrollTop(300)){
//	alert(123);
//}


// 购物车下拉框
$(".top-right-shop").hover(
	function(){
		$(".shop-content").css("display","block");
	},
	function(){
		$(".shop-content").css("display","none");
	}
);

// 输入框的小相机变色
$(".search span").hover(
	function(){
		$(this).addClass("photoChange");
	},
	function(){
		$(this).removeClass("photoChange");
	}
);

// 二维码
$(".QR-Code").hover(
	function(){
		$(".codeBody").css("display","block");
	},
	function(){
		$(".codeBody").css("display","none");
	}
);
