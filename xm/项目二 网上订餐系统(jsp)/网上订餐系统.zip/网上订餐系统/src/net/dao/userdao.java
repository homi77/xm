package net.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import net.bean.loginbean;
import net.bean.userbean;
import net.dbc.dbconn;

public class userdao{
	private Connection conn=null;
	private PreparedStatement ps=null;
	private ResultSet rs=null;
	public userdao(){
		conn=dbconn.getConn();
	}
	public boolean isregistuser(loginbean luser){
		boolean flag=false;
		String sql="select username,psw from usertable where username=? and psw=? ";
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, luser.getUsername());
			ps.setString(2, luser.getPsw());
			rs=ps.executeQuery();
			if(rs.next()){
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	//根据用户名查找
	public userbean findByUsername(String username) {
	    userbean user=null;
	
	    String sql="select * from usertable where username=?";

	    try {
	    	ps = conn.prepareStatement(sql);
	    	ps.setString(1, username);
	        rs = ps.executeQuery();
	        if(rs.next())
				  user = new userbean();  
				  user.setUsername(username);
				  user.setId(rs.getInt("id"));		  
				  user.setPsw(rs.getString("psw"));
				  user.setSex(rs.getString("sex"));
			      user.setPhone(rs.getString("phone"));
			      user.setAddress(rs.getString("address"));

				 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}return user;
		
	}
 	//注册用户
	public boolean doinsert(userbean user){
		boolean flag=false;
		String sql="insert into usertable(username,psw,sex,phone,address) values(?,?,?,?,?)";
		try {
			ps=conn.prepareStatement(sql);

			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPsw());
			ps.setString(3, user.getSex());

			ps.setString(4,user.getPhone());
			ps.setString(5,user.getAddress());
			if(ps.executeUpdate()>0){
				flag=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
		
	}

	 public boolean doupdate(userbean user){
		 boolean flag=false;
			String sql = "update usertable set psw=?,sex=?,phone=?,address=? where username=?";
			try {
				ps=conn.prepareStatement(sql);
				ps.setString(1,user.getPsw());
				ps.setString(2,user.getSex());
				ps.setString(3,user.getPhone());
				ps.setString(4,user.getAddress());
				ps.setString(5,user.getUsername());
				if(ps.executeUpdate()>0){
					flag=true;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}return flag;
	}
	 public boolean dodelete(String username){
		 boolean flag=false;
			String sql = "DELETE FROM usertable WHERE username=?";
			try {
				ps = conn.prepareStatement(sql);
				   ps.setString(1,username);
				   if(ps.executeUpdate()>0)
					{
						flag=true;
					}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}return flag;
			
		}

}
