﻿package net.dao;
import java.sql.*;

import net.bean.foodbean;
import net.bean.shopbean;
import net.dbc.dbconn;

import java.util.ArrayList;
import java.util.List;
public class fooddao {
	private Connection conn=null;
	private PreparedStatement ps=null;
	private ResultSet rs=null;
	
	public fooddao(){
		conn=dbconn.getConn();
	}
	//插入用户
	public boolean doInsert(foodbean user)
	{
		boolean f=false;
		//获取连接
		//操作数据
		String sql="insert into foodtable (canname,canprice,canjianjie,canphoto,type) values(?,?,?,?,?)";
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1,user.getCanname());
			ps.setString(2,user.getCanprice());
			ps.setString(3,user.getCanjianjie());
			ps.setString(4,user.getCanphoto());
			ps.setString(5,user.getType());

			if(ps.executeUpdate()>0)
			{
				f=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return f;
	}	
	
//查找所有
	public List<foodbean> findall(){
		List<foodbean> userbeans = new ArrayList<foodbean>();
		String sql="select * from foodtable";
		foodbean user =null;
		try {
	    	ps=conn.prepareStatement(sql);
	        rs = ps.executeQuery();
			 while(rs.next())
			  {
				 
				  user=new foodbean();
				  user.setCanid(rs.getInt("canid"));
				  user.setCanname(rs.getString("canname"));		  
				  user.setCanprice(rs.getString("canprice"));
				  user.setCanphoto(rs.getString("canphoto"));
			      user.setCanjianjie(rs.getString("canjianjie"));
			      user.setType(rs.getString("type"));

			       userbeans.add(user);
			  }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	         return userbeans;
	    }
	//查找所有

	//个人查询
	public foodbean findByName(String canname) {
		foodbean user=null;
	    String sql="select * from foodtable where canname=?";

	    try {
	    	ps = conn.prepareStatement(sql);
	    	ps.setString(1, canname);
	        rs = ps.executeQuery();
	        if(rs.next())
				  user = new foodbean();  
				  user.setCanname(canname);
				  user.setCanid(rs.getInt("canid"));		  
				  user.setCanprice(rs.getString("canprice"));
				  user.setCanphoto(rs.getString("canphoto"));
			      user.setCanjianjie(rs.getString("canjianjie"));
			      user.setType(rs.getString("type"));

			  
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}return user;
	}
	//删除用户

	public boolean dodelete(String canname){
		 boolean flag=false;
		 String sql = "DELETE FROM foodtable WHERE canname=?";
			try {
				ps = conn.prepareStatement(sql);
				   ps.setString(1,canname);
				   if(ps.executeUpdate()>0)
					{
						flag=true;
					}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}return flag;
			
		}
	//个人修改
	public boolean doupdate(foodbean user){
		 boolean flag=false;
		 String sql = "update foodtable set canprice=?,canphoto=?,canjianjie=?,type=? where canname=?";
			
			try {
				conn=dbconn.getConn();
				ps=conn.prepareStatement(sql);
				ps.setString(1, user.getCanprice());
				ps.setString(2, user.getCanphoto());
				ps.setString(3, user.getCanjianjie());
				ps.setString(4, user.getType());
				ps.setString(5, user.getCanname());
				if(ps.executeUpdate()>0){
					flag=true;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}return flag;
	}
	
	 public foodbean findBytype(String type) {

			foodbean user=null;
		    String sql="select * from foodtable where type=?";

		    try {
		    	ps = conn.prepareStatement(sql);
		    	ps.setString(1, type);
		        rs = ps.executeQuery();
		        if(rs.next())
					  user = new foodbean();  
					  user.setType(type);
					  user.setCanid(rs.getInt("canid"));
					  user.setCanname(rs.getString("canname"));
					  user.setCanprice(rs.getString("canprice"));
					  user.setCanphoto(rs.getString("canphoto"));
				      user.setCanjianjie(rs.getString("canjianjie"));
				    
				  
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}return user;
		}
	//个人搜索
	 public foodbean findCanname(String canname) {

	 	foodbean user=null;
	 	String sql="select * from foodtable where canname=?";

	     try {
	     	ps = conn.prepareStatement(sql);
	     	ps.setString(1, canname);
	         rs = ps.executeQuery();
	         if(rs.next())
	 			  user = new foodbean();  
	 			  user.setCanname(canname);
	 			  user.setCanid(rs.getInt("canid"));		  
	 			  user.setCanprice(rs.getString("canprice"));
	 			  user.setCanphoto(rs.getString("canphoto"));
	 		      user.setCanjianjie(rs.getString("canjianjie"));
	 		      user.setType(rs.getString("type"));

	 		    
	 		  
	 	} catch (Exception e) {
	 		// TODO Auto-generated catch block
	 		e.printStackTrace();
	 	}return user;
	 }
	 public List<foodbean> findallType(String type){
			List<foodbean> userbeans = new ArrayList<foodbean>();
			foodbean user =null;
		    String sql="select * from foodtable where type=?";

		    try {
		    	ps = conn.prepareStatement(sql);
		    	ps.setString(1, type);
		        rs = ps.executeQuery();
				 while(rs.next())
				  {
					 
					  user=new foodbean();
					  user.setType(type);
					  user.setCanname(rs.getString("canname"));
					  user.setCanid(rs.getInt("canid"));
					  user.setCanprice(rs.getString("canprice"));
					  user.setCanjianjie(rs.getString("canjianjie"));
					  user.setCanphoto(rs.getString("canphoto"));

				
				     userbeans.add(user);
				  }
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		         return userbeans;
	 }
}
