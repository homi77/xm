package net.dao;
import java.sql.*;

import net.bean.adminbean;
import net.dbc.dbconn;

import java.util.ArrayList;
import java.util.List;


public class admindao{
	private Connection conn=null;
	private PreparedStatement ps=null;
	private ResultSet rs=null;
	public admindao(){
		conn=dbconn.getConn();
	}
	public boolean isRightadmin(adminbean luser){
		boolean flag=false;
		
		String sql="select adminname,psw from admintable where adminname=? and psw=?";
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, luser.getAdminname());
			ps.setString(2, luser.getPsw());
			rs=ps.executeQuery();
			if(rs.next()){
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
}

