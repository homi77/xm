package net.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import net.bean.foodbean;
import net.bean.orderbean;
import net.bean.shopbean;
import net.dbc.dbconn;

public class orderdao {
	private Connection conn=null;
	private PreparedStatement ps=null;
	private ResultSet rs=null;
	public orderdao(){
		conn=dbconn.getConn();
	}
	public List<orderbean> findall(){
		List<orderbean> userbeans = new ArrayList<orderbean>();
		conn=dbconn.getConn();
		String sql="select * from ordertable";
		orderbean user =null;
		try {
	    	ps=conn.prepareStatement(sql);
	        rs = ps.executeQuery();
			 while(rs.next())
			  {
				 
				  user=new orderbean();
                  user.setOrderid(rs.getInt("orderid"));
                  user.setUsername(rs.getString("username"));
				  user.setPhone(rs.getString("phone"));
                  user.setAddress(rs.getString("address"));
	              user.setNotice(rs.getString("notice"));
	              user.setTimestamp(rs.getTimestamp("timestamp"));
			      user.setTotal(rs.getInt("total"));
			     
			       userbeans.add(user);
			  }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	         return userbeans;
	    }
	public boolean dodelete(int orderid)
	{
		boolean flag=false;
		String sql = "delete from ordertable where orderid=?";
		try {
			ps=conn.prepareStatement(sql);
			ps.setInt(1,orderid);
			if(ps.executeUpdate()>0)
			{
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	public orderbean findByname(String username) {
	    orderbean user=null;
	
	    String sql="select * from ordertable where orderid=?";

	    try {
	    	ps = conn.prepareStatement(sql);
	    	ps.setString(1, username);
	        rs = ps.executeQuery();
	        if(rs.next())
				  user = new orderbean();  
	              user.setUsername("username");
				  user.setOrderid(rs.getInt("orderid"));
				  user.setPhone(rs.getString("phone"));
                  user.setAddress(rs.getString("address"));
	              user.setNotice(rs.getString("notice"));
	              user.setTotal(rs.getInt("total"));

				 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}return user;
	}
	public boolean doinsert(orderbean user){
		boolean flag=false;
		String sql="insert into ordertable(username,phone,address,notice,timestamp,total) values(?,?,?,?,?,?)";
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPhone());
			ps.setString(3, user.getAddress());
			ps.setString(4, user.getNotice());
			ps.setTimestamp(5,new Timestamp(new java.util.Date().getTime()));
			ps.setInt(6,user.getTotal());
			if(ps.executeUpdate()>0){
				flag=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
		
	}
}
