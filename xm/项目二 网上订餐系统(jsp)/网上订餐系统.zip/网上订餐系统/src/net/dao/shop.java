package net.dao;

public class shop {
	private int shopid;
	private int canid;
	private String username;
	private String canname;
	private int canprice;
	private int number;
	private int orderprice;
	private String strSql;
	public shop(){
		this.shopid=0;
		this.canid=0;
		this.username="";
		this.canname="";
		this.canprice=0;
		this.number=0;
		this.orderprice=0;
		this.strSql="";
		
		
	}
}
