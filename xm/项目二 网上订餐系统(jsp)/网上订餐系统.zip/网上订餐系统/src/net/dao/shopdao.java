package net.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import net.bean.foodbean;
import net.bean.shopbean;
import net.dbc.dbconn;

public class shopdao {
		private Connection conn=null;
		private PreparedStatement ps=null;
		private ResultSet rs=null;
		public shopdao(){
			conn=dbconn.getConn();
		}
		public List<shopbean> findall(){
			List<shopbean> list = new ArrayList<shopbean>();
		    String sql="select * from shoptable where username=?";
		    try {
		   	 ps = conn.prepareStatement(sql);
		   	 shopbean user=null;
		        rs = ps.executeQuery();
				 while(rs.next())
				  {
					  user = new shopbean();
					  user.setShopid(rs.getInt("shopid"));
					  user.setCanid(rs.getInt("canid"));
					  user.setUsername(rs.getString("username"));
					  user.setCanname(rs.getString("canname"));
					  user.setCanprice(rs.getInt("canprice"));
					  user.setNumber(rs.getInt("number"));
					  user.setOrderprice(rs.getInt("orderprice"));
					  list.add(user);
				  }
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		         return list;
		    }
		public boolean dodelete(int shopid)
		{
			boolean flag=false;
			String sql = "delete from shoptable where shopid=?";
			try {
				ps=conn.prepareStatement(sql);
				ps.setInt(1,shopid);
				if(ps.executeUpdate()>0)
				{
					flag=true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return flag;
		}
		//注册用户
		public boolean doinsert(shopbean user){
			boolean flag=false;
			String sql="insert into shoptable(canid,username,canname,canprice,number,orderprice) values(?,?,?,?,?,?)";
			try {
				ps=conn.prepareStatement(sql);
				ps.setInt(1,user.getCanid());
				ps.setString(2, user.getUsername());
				ps.setString(3, user.getCanname());
				ps.setInt(4, user.getCanprice());
				ps.setInt(5, user.getNumber());
				ps.setInt(6,user.getOrderprice());
				if(ps.executeUpdate()>0){
					flag=true;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return flag;
			
		}
		//根据用户名查找
		public shopbean findByname(String username) {
		    shopbean user=null;
		
		    String sql="select * from shoptable where username=?";

		    try {
		    	ps = conn.prepareStatement(sql);
		    	ps.setString(1, username);
		        rs = ps.executeQuery();
		        if(rs.next())
					  user = new shopbean();  
					  user.setUsername(username);
					  user.setShopid(rs.getInt("shopid"));
					  user.setCanid(rs.getInt("canid"));
					  user.setCanname(rs.getString("canname"));
					  user.setCanprice(rs.getInt("canprice"));
					  user.setNumber(rs.getInt("number"));
					  user.setOrderprice(rs.getInt("orderprice"));
					 
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}return user;
		}
		public List<shopbean> findallsingal(String username){
			List<shopbean> userbeans = new ArrayList<shopbean>();
			shopbean user =null;
		    String sql="select * from shoptable where username=?";

		    try {
		    	ps = conn.prepareStatement(sql);
		    	ps.setString(1, username);
		        rs = ps.executeQuery();
				 while(rs.next())
				  {
					 
					  user=new shopbean();
					  user.setUsername(username);
					  user.setShopid(rs.getInt("shopid"));
					  user.setCanid(rs.getInt("canid"));
					  user.setCanname(rs.getString("canname"));
					  user.setCanprice(rs.getInt("canprice"));
					  user.setNumber(rs.getInt("number"));
					  user.setOrderprice(rs.getInt("orderprice"));
				     userbeans.add(user);
				  }
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		         return userbeans;
		    }
		public shopbean find(String canname){
			shopbean user=null;
			String sql="select canprice,number from shoptable where canname=?";
			try {
				ps = conn.prepareStatement(sql);
				rs = ps.executeQuery();
				if(rs.next()){
					user.setCanprice(rs.getInt("canprice"));
					user.setNumber(rs.getInt("number"));
				   
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return user;
		}
		public boolean insert(shopbean user){
			boolean flag=false;
			String sql="insert into shoptable(canid,canname,canprice) select canid,canname,canprice from foodtable where shoptable.canid=foodtable.id";
			try {
				ps=conn.prepareStatement(sql);
				if(rs.next())
				user.setCanid(rs.getInt("canid"));
				user.setCanname(rs.getString("canname"));
				user.setCanprice(rs.getInt("canprice"));
				if(ps.executeUpdate()>0){
					ps.setInt(1,user.getCanid());
					ps.setString(2, user.getCanname());
					ps.setInt(3, user.getCanprice());
					flag=true;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return flag;
			
		}
		public boolean add(foodbean user){
			boolean flag=false;
			String sql="insert into shoptable(canid,canname,canprice) values(?,?,?)";
			try {
				ps=conn.prepareStatement(sql);
				ps.setInt(1,user.getCanid());
				ps.setString(2, user.getCanname());
				ps.setString(3, user.getCanprice());
				if(ps.executeUpdate()>0){
					flag=true;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return flag;
			
		}
		public int getTotal(String username){
			 int total=0;
			 String sql="select sum(orderprice) from shoptable where username=?";
			 try {
			    	ps = conn.prepareStatement(sql);
			    	ps.setString(1, username);
			        rs = ps.executeQuery();
			        if(rs.next()){
			        	total=rs.getInt("sum(orderprice)");
			        }

						 
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
		 }
		return total;

	}

	
}
