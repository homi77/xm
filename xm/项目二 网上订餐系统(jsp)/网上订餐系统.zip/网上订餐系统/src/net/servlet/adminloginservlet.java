package net.servlet;
import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import java.sql.*;
import java.io.PrintWriter;

import net.bean.*;
import net.dao.*;

/**
 * Servlet implementation class adminloginservlet
 */
public class adminloginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public adminloginservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		request.setCharacterEncoding("UTF-8");
	    adminbean luser=new adminbean();
		luser.setAdminname(request.getParameter("adminname"));
		luser.setPsw(request.getParameter("psw"));


	  
	  admindao udao=new admindao();
	  if(udao.isRightadmin(luser)){
		  request.getSession().setAttribute("adminname", luser.getAdminname());				    
		  response.sendRedirect("Yguanli.jsp");	  
	  	
		  
		 
	  }else{
		  String message="您不是管理员，您无权进入管理系统！";
			 request.setAttribute("message", message);
			 request.getRequestDispatcher("").forward(request, response);
		 } 
}
}
