package net.servlet;
import net.bean.foodbean;


import net.dao.fooddao;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.bean.loginbean;
import net.bean.userbean;
import net.dao.userdao;

/**
 * Servlet implementation class loginactionservlet
 */
public class loginactionservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginactionservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		loginbean luser=new loginbean();
		luser.setUsername(request.getParameter("username"));
		luser.setPsw(request.getParameter("psw"));
		 userdao udao=new userdao();
		  if(udao.isregistuser(luser)){
			  userbean user=udao.findByUsername(luser.getUsername());
			  request.getSession().setAttribute("username", luser.getUsername());  //jsp默认对象
			  request.getSession().setAttribute("id",user.getId());
				 response.sendRedirect("index.jsp");  
		  }else{
			  String message="用户名或密码错误，请重新输入！";
				request.setAttribute("message",message);
				request.getRequestDispatcher("login.jsp").forward(request,response);  
		  }
		
	}

}
