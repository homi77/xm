package net.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.bean.foodbean;
import net.dao.fooddao;
import net.dao.shopdao;
import net.dao.userdao;

/**
 * Servlet implementation class doinsertservlet
 */
public class doinsertservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public doinsertservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
        foodbean luser=new foodbean();
		luser.setCanid(Integer.parseInt(request.getParameter("canid")));
		String canname=new String(request.getParameter("canname").getBytes("ISO-8859-1"),"UTF-8");
		luser.setCanname(canname);
		luser.setCanprice(request.getParameter("canprice"));
		 shopdao udao=new shopdao();
		  if(udao.add(luser)){
			  response.sendRedirect("");
				out.println("添加购物车成功！");
			}else{
				out.println("数据插入失败");
			}
		
	}

}
