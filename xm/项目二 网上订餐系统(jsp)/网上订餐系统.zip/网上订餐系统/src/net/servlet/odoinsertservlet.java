package net.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.bean.orderbean;
import net.dao.orderdao;

/**
 * Servlet implementation class odoinsertservlet
 */
public class odoinsertservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public odoinsertservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		request.setCharacterEncoding("UTF-8");
		
		orderbean user=new orderbean();
		String username=new String(request.getParameter("username").getBytes("ISO-8859-1"),"UTF-8");
		user.setUsername(username);
		user.setPhone(request.getParameter("phone"));
		String address=new String(request.getParameter("address").getBytes("ISO-8859-1"),"UTF-8");
		user.setAddress(address);
		String notice=new String(request.getParameter("notice").getBytes("ISO-8859-1"),"UTF-8");
		user.setNotice(notice);
		
		user.setTotal(Integer.parseInt(request.getParameter("total")));;
		PrintWriter out=response.getWriter();
		orderdao udao=new orderdao();
		if(udao.doinsert(user)){
			response.sendRedirect("success.jsp");
			out.print("订餐成功!");
		}else{
			out.println("数据插入失败");
		}
		
		
	}

}
