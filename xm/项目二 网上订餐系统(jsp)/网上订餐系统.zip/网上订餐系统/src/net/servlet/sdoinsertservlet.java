package net.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.bean.foodbean;
import net.bean.shopbean;
import net.dao.shopdao;

/**
 * Servlet implementation class sdoinsertservlet
 */
public class sdoinsertservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public sdoinsertservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		request.setCharacterEncoding("UTF-8");
		shopbean user=new shopbean();
		user.setCanid(Integer.parseInt(request.getParameter("canid")));
		String username=new String(request.getParameter("username").getBytes("ISO-8859-1"),"UTF-8");
		user.setUsername(username);
		String canname=new String(request.getParameter("canname").getBytes("ISO-8859-1"),"UTF-8");
		user.setCanname(canname);
		user.setCanprice(Integer.parseInt(request.getParameter("canprice")));
		user.setNumber(Integer.parseInt(request.getParameter("number")));
        shopdao udao=new shopdao();
		if(udao.doinsert(user)){
			response.sendRedirect("sfindbynameservlet");
			out.println("添加购物车成功！");
		}else{
			out.println("数据插入失败");
		}
	}

}
