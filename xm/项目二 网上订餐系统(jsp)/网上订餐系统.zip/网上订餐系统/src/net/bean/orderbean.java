package net.bean;

import java.sql.Timestamp;

public class orderbean {
   private int orderid;
   private String username;
   private String phone;
   private String address;
   private String notice;
   private Timestamp timestamp;
   private int total;
public int getOrderid() {
	return orderid;
}
public void setOrderid(int orderid) {
	this.orderid = orderid;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getNotice() {
	return notice;
}
public void setNotice(String notice) {
	this.notice = notice;
}

public Timestamp getTimestamp() {
	return timestamp;
}
public void setTimestamp(Timestamp timestamp) {
	this.timestamp = timestamp;
}
public int getTotal() {
	return total;
}
public void setTotal(int total) {
	this.total = total;
}







}
