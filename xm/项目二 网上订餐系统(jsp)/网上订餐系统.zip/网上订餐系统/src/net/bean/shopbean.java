package net.bean;


public class shopbean {
	private int shopid;
	private int canid;
	private String username;
	private String canname;
	private int canprice;
	private int number;
	private int orderprice;
	public int getShopid() {
		return shopid;
	}
	public void setShopid(int shopid) {
		this.shopid = shopid;
	}
	public int getCanid() {
		return canid;
	}
	public void setCanid(int canid) {
		this.canid = canid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getCanname() {
		return canname;
	}
	public void setCanname(String canname) {
		this.canname = canname;
	}
	public int getCanprice() {
		return canprice;
	}
	public void setCanprice(int canprice) {
		this.canprice = canprice;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public int getOrderprice() {
		return orderprice;
	}
	public void setOrderprice(int orderprice) {
		this.orderprice = orderprice;
	}

	

}
