package net.bean;

public class foodbean {
	private int canid;
	private String canname;
	private String canprice;
	private String canphoto;
	private String canjianjie;
	private String type;
	public int getCanid() {
		return canid;
	}
	public void setCanid(int canid) {
		this.canid = canid;
	}
	public String getCanname() {
		return canname;
	}
	public void setCanname(String canname) {
		this.canname = canname;
	}
	public String getCanprice() {
		return canprice;
	}
	public void setCanprice(String canprice) {
		this.canprice = canprice;
	}
	public String getCanphoto() {
		return canphoto;
	}
	public void setCanphoto(String canphoto) {
		this.canphoto = canphoto;
	}
	public String getCanjianjie() {
		return canjianjie;
	}
	public void setCanjianjie(String canjianjie) {
		this.canjianjie = canjianjie;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
}
